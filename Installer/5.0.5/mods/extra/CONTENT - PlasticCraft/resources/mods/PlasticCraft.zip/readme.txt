PlasticCraft v2.3 for Minecraft 1.0.0
Moar technologiez.

Version 2.3 Changelog:
+ Added plastic toolset.
+ Add kevlar armorset.
+ Added jello.
* Plastic bottles now have a drinking animation.
* Changed various recipes.
* Added missing extractor recipes.

Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF from your minecraft.jar and close.
3. Install ModLoader and MinecraftForge into your minecraft.jar
4. Copy PlasticCraft.zip into /.minecraft/mods/
5. Start up minecraft and play.

On encountering an error:
- Copypaste the error into a post on my thread, surrounded by [code][/code] tags. If there are not [code] tags, I will probably ignore it.

Recipes: http://wiki.technicpack.net/index.php?title=PlasticCraft

FAQ:
(Read before posting on thread)^

Q: I haz blackscreen. Fix.
A: Delete META-INF.

Q: I installed this on (not 1.0.0) but I got blackscreen..
A: This mod is for 1.0.0.

Q: Why duzzn't recipes working?
A: Did you install ModLoader?

Q: "java.lang.NoClassDefFoundError: ModLoader" or "java.lang.NoClassDefFoundError: BaseMod"
A: Get ModLoader.

Q: "java.lang.IllegalArgumentException: Slot X is already occupied by Y@d1e7c2 when adding Z@c68a98"
A: Change X in PlasticCraft.cfg to something that isn't used. *this error means ID conflict*

Q: "java.lang.Exception: No more empty item sprite indices left!"
A: You have too many mods.

Q: How open .cfg file?
A: Notepad may, but I recommend Notepad++.

^ = If your problem isn't solved here, post an error log, and add "lolcat" to the end of your post. That way, I know you actually read this thing.