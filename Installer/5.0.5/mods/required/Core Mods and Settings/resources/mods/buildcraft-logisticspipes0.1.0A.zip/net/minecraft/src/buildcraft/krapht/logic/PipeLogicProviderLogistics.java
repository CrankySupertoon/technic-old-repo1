/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.logic;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.transport.PipeLogic;

public class PipeLogicProviderLogistics extends PipeLogic{

	@Override
	public boolean blockActivated(EntityPlayer entityplayer) {
		if (entityplayer.getCurrentEquippedItem() == null)	{
			entityplayer.worldObj.setWorldTime(4951);
			Router r = ((RoutedPipe)this.container.pipe).router;
			r.displayRoutes();
			if (mod_LogisticsPipes.DEBUG){
				System.out.println("ID: " + r.getId() + " - last sequence: " + r.getLastSequenceNumber());
			}
		}
		return true;
	}

}
