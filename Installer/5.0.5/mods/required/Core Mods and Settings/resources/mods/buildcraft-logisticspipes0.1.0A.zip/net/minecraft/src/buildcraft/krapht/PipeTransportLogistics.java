/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.Iterator;
import java.util.LinkedList;

import net.minecraft.src.TileEntity;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeTransportLogistics extends PipeTransportItems {
	
	public PipeTransportLogistics() {
		allowBouncing = true;
	}
	
	//TODO: Refactor to reduce code duplication
	@Override
	public Orientations resolveDestination(EntityData data) {
		
		//PipeLogicLogistics logic = (PipeLogicLogistics)container.pipe.logic;
		RoutedPipe pipe = (RoutedPipe)container.pipe;
		
		if (!(data.item instanceof RoutedEntityItem )){
			//Get specific route
			boolean isDefault = false;

			Router bestRouter = LogisticsManager.getDestinationFor(ItemIdentifier.get(data.item.item), pipe.router.RouteTable.keySet());
			if (bestRouter == null)
			{
				bestRouter = LogisticsManager.getDestinationFor(null, pipe.router.RouteTable.keySet());
				isDefault = true;
			}

			if (bestRouter != null)	{
				RoutedEntityItem newItem = new RoutedEntityItem(this.worldObj, data.item);
				newItem.destinationRouter = bestRouter;
				newItem.isDefaultRouted = isDefault;
				data.item = newItem;
				data.item.speed = Math.max(data.item.speed, Utils.pipeNormalSpeed * (isDefault?mod_LogisticsPipes.LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER : mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER));
				if (bestRouter != pipe.router){
					return pipe.router.RouteTable.get(bestRouter);
				}
			}
			//No route, drop item
			if (bestRouter != pipe.router) {
				return Orientations.Unknown;
			}
		}
		RoutedEntityItem item = (RoutedEntityItem)data.item;
		
		if (item.destinationRouter == null)	{
			//a routed item with destination stripped. Check if we can get new route
			Router bestRouter = LogisticsManager.getDestinationFor(ItemIdentifier.get(data.item.item), pipe.router.RouteTable.keySet());
			if (bestRouter != null) {
				item.isDefaultRouted = false;
				item.destinationRouter = bestRouter;
			}
			else {
				bestRouter = LogisticsManager.getDestinationFor(null, pipe.router.RouteTable.keySet());
				item.isDefaultRouted = true;
			}
		}
		if (item.destinationRouter == pipe.router){
			//1) Deliver to attached chest/non-pipe
			LinkedList<Orientations> possible = getPossibleMovements(getPosition(), item);
			Iterator<Orientations> iterator = possible.iterator();
			while (iterator.hasNext())	{
				Position p = new Position(pipe.xCoord, pipe.yCoord, pipe.zCoord, iterator.next());
				p.moveForwards(1);
				TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
				if (tile instanceof TileGenericPipe){
					iterator.remove();
				}
			}
			if (possible.size() > 0){
				return possible.get(worldObj.rand.nextInt(possible.size()));
			}
				
			
			
			//2) Strip item of destination and deliver to attached pipe that does not have a route
			item.destinationRouter = null;
			LinkedList<Orientations> nonRoutes = pipe.router.GetNonRoutedExits();
			iterator = nonRoutes.iterator();
			while(iterator.hasNext()) {
				Position p = new Position(pipe.xCoord, pipe.yCoord, pipe.zCoord, iterator.next());
				p.moveForwards(1);
				TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z); 
				if (tile == null || !( tile instanceof TileGenericPipe) || !((TileGenericPipe)tile).acceptItems()){
					iterator.remove();
				}
			}

			if (nonRoutes.size() != 0){
				return nonRoutes.get(worldObj.rand.nextInt(nonRoutes.size()));
			}
			
			//3) Eject				
			return Orientations.Unknown;
		}

		Orientations exit = pipe.router.RouteTable.get(item.destinationRouter); 
		if (exit != null) {
			data.item.speed = Math.max(data.item.speed, Utils.pipeNormalSpeed * (item.isDefaultRouted?mod_LogisticsPipes.LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER : mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER));
			return(exit);
		}

		return super.resolveDestination(data);
	}
}
