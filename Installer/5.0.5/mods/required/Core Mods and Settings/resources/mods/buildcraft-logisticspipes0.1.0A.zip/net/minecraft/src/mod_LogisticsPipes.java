/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */


/*
TODO: now
 - Add ingame item to view see routes between two nodes. (useful for debugging, both code and in-game routes)
 - REMOVE DEBUG CODE (always)
 - Write manual / wiki
 
DONE:
 - Alternate texture for routed exits
 - Performance related fix that caused recalculation of shortest even when paths had not changed.
 - Fixed bug that was could cause items to slow down if it was inputed at speeds higher than the speed the router would send them.
 - "Fixed" routing bug - network wasn't converging when loading world
 - Iron pipes separate network segments
 - Crafting, need specify input->output for logistics in gui (dynamic recepies)
 - Logs to modloader.txt which texture ids it gets from buildcraft
  
 NOTES:
 	Logisticsmanagement needs transaction support
 	Status screen (in transit, waiting for craft, ready etc)
 	
 	On craft delivery, if can not deliver, check attached chest with attached router pipe, deliver there (double chests!)
 	RoutedEntityItem, targetTile - specify which "chest" it should be delivered to
 	
 
TODO later, maybe....
 - Change recepies to chipsets in 3.0.0.0
 - Add ingame item for network management (turn on/off link detection, poke link detection etc) ?
 - Context sensitive textures. Flashing routers on deliveries?
 - Logistics exchanger, able to pull requested items from attached chest (impl)
 	- Reserved items
 	- Queue sending items
 	- Inventory station, check count of all items and send requests
 	- Productional exchanger. Request resources to auto crafting table / pull result, or configurable for every other converter 
 - Track deliveries / en route ?
 - Save stuff, like destinations
 - Texture improvement
 - Persistance:
 	- Save logistics to file. Save coordinates so they can be resolved later. Also save items in transit and count them as not delivered
 - SMP:
	- Peering, transport other peoples items. Need hook to set owner of PassiveEntity
 */

package net.minecraft.src;

import java.io.File;


import net.minecraft.src.buildcraft.core.CoreProxy;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsBasicLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsCraftingLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsProviderLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsRequestLogistics;
//import net.minecraft.src.buildcraft.krapht.PipeItemsBasicLogistics;Logistics;
import net.minecraft.src.buildcraft.transport.BlockGenericPipe;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.forge.Configuration;
import net.minecraft.src.forge.MinecraftForgeClient;
import net.minecraft.src.forge.Property;

public class mod_LogisticsPipes extends BaseMod{
	
	public static boolean DEBUG = false;
	
	//Items
	public static Item LogisticsBasicPipe;
	public static Item LogisticsRequestPipe;
	public static Item LogisticsProviderPipe;
	public static Item LogisticsCraftingPipe;
	
	
	//Ids
	public static int LOGISTICSPIPE_BASIC_ID						= 6874;
	public static int LOGISTICSPIPE_REQUEST_ID						= 6875;
	public static int LOGISTICSPIPE_PROVIDER_ID						= 6876;
	public static int LOGISTICSPIPE_CRAFTING_ID						= 6877;
	
	//Texture #
	public static int LOGISTICSPIPE_TEXTURE					= 0;
	public static int LOGISTICSPIPE_PROVIDER_TEXTURE		= 0;
	public static int LOGISTICSPIPE_REQUESTER_TEXTURE		= 0;
	public static int LOGISTICSPIPE_CRAFTER_TEXTURE			= 0;
	public static int LOGISTICSPIPE_ROUTED_TEXTURE			= 0;
	public static int LOGISTICSPIPE_NOTROUTED_TEXTURE		= 0;
	
	//Texture files
	public static final String LOGISTICSPIPE_TEXTURE_FILE			= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipe.png";
	public static final String LOGISTICSPIPE_PROVIDER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipeprovider.png";
	public static final String LOGISTICSPIPE_REQUESTER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspiperequester.png";
	public static final String LOGISTICSPIPE_CRAFTER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipecrafter.png";
	public static final String LOGISTICSPIPE_ROUTED_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspiperouted.png";
	public static final String LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipenotrouted.png";
	
	//Configrables
	public static int LOGISTICS_DETECTION_LENGTH	= 50;
	public static int LOGISTICS_DETECTION_COUNT		= 100;
	public static int LOGISTICS_DETECTION_FREQUENCY = 20;
	
	public static final float LOGISTICS_ROUTED_SPEED_MULTIPLIER	= 20F;
	public static final float LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER = 5F;
	
	private static Configuration configuration;
	
	@Override
	public void ModsLoaded() {
		super.ModsLoaded();
		
		File configFile = new File(CoreProxy.getBuildCraftBase(), "config/LogisticsPipes.cfg");
		configuration = new Configuration(configFile);
		configuration.load();
		
		Property logisticPipeIdProperty = configuration.getOrCreateIntProperty("logisticsPipe.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_BASIC_ID);
		logisticPipeIdProperty.comment = "The item id for the basic logistics pipe";
		
		Property logisticPipeRequesterIdProperty = configuration.getOrCreateIntProperty("logisticsPipeRequester.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_REQUEST_ID);
		logisticPipeRequesterIdProperty.comment = "The item id for the requesting logistics pipe";
		
		Property logisticPipeProviderIdProperty = configuration.getOrCreateIntProperty("logisticsPipeProvider.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_PROVIDER_ID);
		logisticPipeProviderIdProperty.comment = "The item id for the providing logistics pipe";
		
		Property logisticPipeCraftingIdProperty = configuration.getOrCreateIntProperty("logisticsPipeCrafting.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_CRAFTING_ID);
		logisticPipeCraftingIdProperty.comment = "The item id for the crafting logistics pipe";

		
		Property detectionLength = configuration.getOrCreateIntProperty("detectionLength", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_LENGTH);
		detectionLength.comment = "The maximum shortest length between logistics pipes. This is an indicator on the maxim depth of the recursion algorithm to discover logistics neighbours. A low value might use less CPU, a high value will allow longer pipe sections";
		
		Property detectionCount = configuration.getOrCreateIntProperty("detectionCount", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_COUNT);
		detectionCount.comment = "The maximum number of buildcraft pipees (including forks) between logistics pipes. This is an indicator of the maximum ammount of nodes the recursion algorithm will visit before giving up. As it is possible to fork a pipe connection using standard BC pipes the algorithm will attempt to discover all available destinations through that pipe. Do note that the logistics system will not interfere with the operation of non-logistics pipes. So a forked pipe will usually be sup-optimal, but it is possible. A low value might reduce CPU usage, a high value will be able to handle more complex pipe setups. If you never fork your connection between the logistics pipes this has the same meaning as detectionLength and the lower of the two will be used";
		
		Property detectionFrequency = configuration.getOrCreateIntProperty("detectionFrequency", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_FREQUENCY);
		detectionFrequency.comment = "The amount of time that passes between checks to see if it is still connected to its neighbours. A low value will mean that it will detect changes faster but use more CPU. A high value means detection takes longer, but CPU consumption is reduced. A value of 20 will check about every second";
				
		configuration.save();
		 
		LOGISTICSPIPE_BASIC_ID 			= Integer.parseInt(logisticPipeIdProperty.value);
		LOGISTICSPIPE_REQUEST_ID		= Integer.parseInt(logisticPipeRequesterIdProperty.value);
		LOGISTICSPIPE_PROVIDER_ID		= Integer.parseInt(logisticPipeProviderIdProperty.value);
		LOGISTICSPIPE_CRAFTING_ID		= Integer.parseInt(logisticPipeCraftingIdProperty.value);
		LOGISTICS_DETECTION_LENGTH		= Integer.parseInt(detectionLength.value);
		LOGISTICS_DETECTION_COUNT		= Integer.parseInt(detectionCount.value);
		LOGISTICS_DETECTION_FREQUENCY 	= Math.max(Integer.parseInt(detectionFrequency.value), 1);

		LOGISTICSPIPE_TEXTURE 			= CoreProxy.addCustomTexture(LOGISTICSPIPE_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_TEXTURE + " for base texture");
		LOGISTICSPIPE_PROVIDER_TEXTURE 	= CoreProxy.addCustomTexture(LOGISTICSPIPE_PROVIDER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_PROVIDER_TEXTURE + " for provider texture");
		LOGISTICSPIPE_REQUESTER_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_REQUESTER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_REQUESTER_TEXTURE + " for requester texture");
		LOGISTICSPIPE_CRAFTER_TEXTURE	= CoreProxy.addCustomTexture(LOGISTICSPIPE_CRAFTER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_CRAFTER_TEXTURE + " for crafter texture");
		LOGISTICSPIPE_ROUTED_TEXTURE 	= CoreProxy.addCustomTexture(LOGISTICSPIPE_ROUTED_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_ROUTED_TEXTURE + " for routed texture");
		LOGISTICSPIPE_NOTROUTED_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_NOTROUTED_TEXTURE + " for non-routed texture");
		
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_PROVIDER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_REQUESTER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_CRAFTER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_ROUTED_TEXTURE_FILE);		
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE);
		
		LogisticsBasicPipe = createPipe(LOGISTICSPIPE_BASIC_ID, PipeItemsBasicLogistics.class, "Basic Logistics Pipe");
		LogisticsRequestPipe = createPipe(LOGISTICSPIPE_REQUEST_ID, PipeItemsRequestLogistics.class, "Request Logistics Pipe");
		LogisticsProviderPipe = createPipe(LOGISTICSPIPE_PROVIDER_ID, PipeItemsProviderLogistics.class, "Provider Logistics Pipe");
		LogisticsCraftingPipe = createPipe(LOGISTICSPIPE_CRAFTING_ID, PipeItemsCraftingLogistics.class, "Crafting Logistics Pipe");
		
		CraftingManager craftingmanager = CraftingManager.getInstance();
		craftingmanager.addRecipe(new ItemStack(LogisticsBasicPipe, 8), new Object[] { "grg", "GdG", "grg", Character.valueOf('g'), Block.glass, 
																									   Character.valueOf('G'), BuildCraftCore.goldGearItem,
																									   Character.valueOf('d'), BuildCraftTransport.pipeItemsDiamond, 
																									   Character.valueOf('r'), Block.torchRedstoneActive});
		
		craftingmanager.addRecipe(new ItemStack(LogisticsRequestPipe, 1), new Object[] { "P", "d", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond}); 
		craftingmanager.addRecipe(new ItemStack(LogisticsProviderPipe, 1), new Object[] { "d", "P", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond});
		craftingmanager.addRecipe(new ItemStack(LogisticsProviderPipe, 1), new Object[] { "d", "P", "d", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond});
		
		
		if (mod_LogisticsPipes.DEBUG) {
			craftingmanager.addRecipe(new ItemStack(LogisticsBasicPipe, 64), new Object[] { "wd", Character.valueOf('w'), Block.wood, Character.valueOf('d'), Block.dirt}); 
			craftingmanager.addRecipe(new ItemStack(LogisticsRequestPipe, 64), new Object[] {"ww", Character.valueOf('w'), Block.wood});
			craftingmanager.addRecipe(new ItemStack(LogisticsProviderPipe, 64), new Object[] {"dd", Character.valueOf('d'), Block.dirt});
			craftingmanager.addRecipe(new ItemStack(LogisticsCraftingPipe, 64), new Object[] {"ddd", Character.valueOf('d'), Block.dirt});
		}
	}
	
	@Override
	public String getVersion() {
		return "0.1.0 (Minecraft 1.0.0, Buildcraft 2.2.7, Forge 1.2.0)";
	}
	
	private static Item createPipe (int defaultID, Class <? extends Pipe> clas, String descr) {
		String name = Character.toLowerCase(clas.getSimpleName().charAt(0))
				+ clas.getSimpleName().substring(1);
		
		Item res =  BlockGenericPipe.registerPipe (defaultID, clas);
		res.setItemName(clas.getSimpleName());
		CoreProxy.addName(res, descr);
		MinecraftForgeClient.registerCustomItemRenderer(res.shiftedIndex, mod_BuildCraftTransport.instance);
	
		return res;
	}

	@Override
	public void load() {
		// TODO Auto-generated method stub
		
	}
}
