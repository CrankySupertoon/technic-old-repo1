/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import net.minecraft.src.BuildCraftTransport;
import net.minecraft.src.ChunkCache;
import net.minecraft.src.ModLoader;
import net.minecraft.src.RenderBlocks;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.transport.BlockGenericPipe;
import net.minecraft.src.forge.MinecraftForgeClient;
import net.minecraft.src.krapht.ItemIdentifier;

public class Router {

	public class LSA {
		public Router source;
		public long sequenceNumber;
		public HashMap<Router, Integer> neighboursWithMetric;
		boolean expired = false;
	}
	
	public HashMap<RoutedPipe, ExitRoute> _adjacent = new HashMap<RoutedPipe, ExitRoute>();
	//	
	private LinkedList<LSA> _incommingLSA = new LinkedList<LSA>();
	private LinkedList<LSA> _outgoingLSA = new LinkedList<LSA>();
	private boolean _LSDNeedUpdate = false;
	private RoutedPipe _pipe;
	private LSA _lastSentLSA;
	
	private static RouteLaser _laser = new RouteLaser();
	
	private long _lastSequenceNumber = 0;
	
	/** Contains a list of all received LSAs **/
	public LinkedList<LSA> LSADatabase = new LinkedList<Router.LSA>();
	
	/** Map of router -> orientation for all known destinations **/
	public HashMap<Router, Orientations> RouteTable = new HashMap<Router, Orientations>();
	public HashMap<Router, Integer> RouteCosts = new HashMap<Router, Integer>();
	
	
	public Router(RoutedPipe pipe){
		this._pipe = pipe;
	}

		
	public void update(boolean doFullRefresh){
		processOutgoingList();
		if (doFullRefresh) {
			recheckAdjacent();
			ValidateSLAWithAdjacent();
		}
		processIncommingList();
		
		if (_LSDNeedUpdate){
			groomLSADatabase();
			CreateRouteTable();
			_pipe.worldObj.markBlockAsNeedsUpdate(this._pipe.xCoord, this._pipe.yCoord, this._pipe.zCoord);
			_LSDNeedUpdate = false;
		}

	}
	
	public RoutedPipe getPipe() {
		return _pipe;
	}
	
	public String getId() {
		return this.toString().substring(this.toString().indexOf('@'));
	}
	
	/**
	 * Interface for other routers to inject LSAs 
	 * @param incomming
	 */
	public void addLSA(LSA incomming){
		_incommingLSA.push(incomming);
	}
	
	/**
	 * Process the list of received LSAs since last update
	 */
	public void processIncommingList() {
		while (!_incommingLSA.isEmpty()) {
			LSA incommingLSA = _incommingLSA.pop();
			
			if (incommingLSA.source == this)
				continue;
			
			//Check if we know this LSA already
			Iterator<LSA> iterator = LSADatabase.iterator();
			boolean known = false;
			while(iterator.hasNext()){
				LSA knownLSA = iterator.next();
				if (incommingLSA.source == knownLSA.source){
						if (incommingLSA.sequenceNumber <= knownLSA.sequenceNumber){
							known = true;
							break;
						}
						//We have a LSA from this router, but its not the latest, so remove the old one in preparation for the new one
						iterator.remove();
				}
			}
			//TODO: REFACTOR
			if (!known) {
				//New information, save it and add it to flood list
				//System.out.println(this.getId() + ": Recieved unknown LSA for " + incommingLSA.source.getId() + "with sequence number " + incommingLSA.sequenceNumber);
				LSADatabase.add(incommingLSA);
				_LSDNeedUpdate = true;
				_outgoingLSA.push(incommingLSA);

			}
		}
	}
	
	/**
	 * Clears the LSADatabase of expired LSA
	 */
	public void groomLSADatabase()	{
		Iterator<LSA> iterator = LSADatabase.iterator();
		while (iterator.hasNext()){
			LSA lsa = iterator.next();
			if (lsa.expired) {
				_LSDNeedUpdate = true;
				iterator.remove();
			}
		}
	}
	
	/**
	 * Process the list of LSAs to flood to neighbors
	 */
	public void processOutgoingList(){
		while (!_outgoingLSA.isEmpty()){
			LSA outgoingLSA = _outgoingLSA.pop();
			UpdateAdjacent(outgoingLSA);
		}
	}
	
	/** Push all LSA to a router **/
	public void pushLSAtoRouter(Router destination)	{
		for (LSA lsa : LSADatabase) {
			destination.addLSA(lsa);			
		}
	}
	
	/**
	 * Sends a LSA to all adjacent routers
	 * @param outgoing
	 */
	public void UpdateAdjacent(LSA outgoing){
		for(RoutedPipe adjacent : _adjacent.keySet()){
			adjacent.router.addLSA(outgoing);
		}
	}
	
	
	/**
	 * Rechecks the piped connection to all adjacent routers as well as discover new ones.
	 */
	public void recheckAdjacent()	{
		boolean adjacentChanged = false;
		HashMap<RoutedPipe, ExitRoute> adjacent = PathFinder.getConnectedRoutingPipes(_pipe.container, mod_LogisticsPipes.LOGISTICS_DETECTION_COUNT, mod_LogisticsPipes.LOGISTICS_DETECTION_LENGTH);
		
		for (RoutedPipe pipe : _adjacent.keySet()){
			if(!adjacent.containsKey(pipe))
				adjacentChanged = true;
		}
		
		for (RoutedPipe pipe : adjacent.keySet())	{
			if (!_adjacent.containsKey(pipe)){
				adjacentChanged = true;
				pushLSAtoRouter(pipe.router);
				break;
			}
			ExitRoute newExit = adjacent.get(pipe);
			ExitRoute oldExit = _adjacent.get(pipe);
			
			if (newExit.exitOrientation != oldExit.exitOrientation || newExit.metric != oldExit.metric)	{
				adjacentChanged = true;
				break;
			}
		}
		
		if (adjacentChanged){
			_adjacent = adjacent;
			//System.out.println("Adjacent changed");
			_LSDNeedUpdate = true;
			SendNewLSA();
		}
	}
	
	/**
	 * Creates an updated LSA and add it to send queue;
	 */
	public void SendNewLSA()
	{
		LSA newLSA = new LSA();
		if (_lastSequenceNumber == Long.MAX_VALUE){
			_lastSequenceNumber = 0;
		}
		newLSA.sequenceNumber = ++this._lastSequenceNumber;
		newLSA.source = this;
		newLSA.neighboursWithMetric = new HashMap<Router, Integer>();
		for (RoutedPipe adjacent : _adjacent.keySet()){
			newLSA.neighboursWithMetric.put(adjacent.router, _adjacent.get(adjacent).metric);
		}
		_lastSentLSA = newLSA;
		_outgoingLSA.add(newLSA);
		//System.out.println(this.getId() + ": creating new LSA with number " + newLSA.sequenceNumber);

	}
	
	public void ValidateSLAWithAdjacent(){
		for (RoutedPipe pipe : _adjacent.keySet()){
			if (pipe.router.LSADatabase.size() != this.LSADatabase.size()){
				pushLSAtoRouter(pipe.router);
			}
		}
	}
	
	
	/**
	 * Create a route table from the link state database
	 */
	public void CreateRouteTable()	{ 
		//Dijkstra!
		
		/** Map of all "approved" routers and the route to get there **/
		HashMap<Router, LinkedList<Router>> tree =  new HashMap<Router, LinkedList<Router>>();
		/** The cost to get to an "approved" router **/
		HashMap<Router, Integer> treeCost = new HashMap<Router, Integer>();
		
		//Init root(er - lol)
		tree.put(this,  new LinkedList<Router>());
		treeCost.put(this,  0);
		/** The candidate router and which approved router put it in the candidate list **/
		HashMap<Router, Router> candidates = new HashMap<Router, Router>();
		/** The total cost for the candidate route **/
		HashMap<Router, Integer> candidatesCost = new HashMap<Router, Integer>();
		
		//Init candidates
		for (RoutedPipe pipe :  _adjacent.keySet()){
			candidates.put(pipe.router, this);
			candidatesCost.put(pipe.router, _adjacent.get(pipe).metric);
		}

		
		while (!candidates.isEmpty()){
			Router lowestCostCandidateRouter = null;
			int lowestCost = Integer.MAX_VALUE;
			for(Router candidate : candidatesCost.keySet()){
				if (candidatesCost.get(candidate) < lowestCost){
					lowestCostCandidateRouter = candidate;
					lowestCost = candidatesCost.get(candidate);
				}
			}
			
			Router lowestParent = candidates.get(lowestCostCandidateRouter);	//Get the approved parent of the lowest cost candidate
			LinkedList<Router> lowestPath = (LinkedList<Router>) tree.get(lowestParent).clone();	//Get a copy of the route for the approved router 
			lowestPath.addLast(lowestCostCandidateRouter); //Add to the route to get to the candidate
			
			//Approve the candidate
			tree.put(lowestCostCandidateRouter, lowestPath);
			treeCost.put(lowestCostCandidateRouter, lowestCost);
			
			//Remove from candidate list
			candidates.remove(lowestCostCandidateRouter);
			candidatesCost.remove(lowestCostCandidateRouter);
			
			//Add new candidates from the newly approved route
			for (LSA lsa : this.LSADatabase){
				if (lsa.source != lowestCostCandidateRouter) continue;				
				for (Router newCandidate: lsa.neighboursWithMetric.keySet()){
					if (tree.containsKey(newCandidate)) continue;
					int candidateCost = lowestCost + lsa.neighboursWithMetric.get(newCandidate);
					if (candidates.containsKey(newCandidate) && candidatesCost.get(newCandidate) <= candidateCost){
						continue;
					}
					candidates.put(newCandidate, lowestCostCandidateRouter);
					candidatesCost.put(newCandidate, candidateCost);
				}
			}
		}
		
		
		//Build route table
		
		RouteTable = new HashMap<Router, Orientations>();
		RouteCosts = new HashMap<Router, Integer>();
		for (Router node : tree.keySet())
		{
			LinkedList<Router> route = tree.get(node);
			if (route.size() == 0){
				RouteTable.put(node, Orientations.Unknown);
				continue;
			}
			
			Router firstHop = route.getFirst();
			if (!_adjacent.containsKey(firstHop._pipe)){
				//System.out.println("FirstHop is not adjacent!");
			}
			RouteCosts.put(node, treeCost.get(node));
			RouteTable.put(node, _adjacent.get(firstHop._pipe).exitOrientation);
		}
	}

	public long getLastSequenceNumber()
	{
		return _lastSequenceNumber;
	}
	
	/**
	 * Flags the last sent LSA as expired. Each router will be responsible of purging it from its database.
	 */
	public void destroy() {
		if (_lastSentLSA != null){
			_lastSentLSA.expired = true;
			//System.out.println("Router removed");
		}
			
	}
	
	public LinkedList<Orientations> GetNonRoutedExits()	{
		LinkedList<Orientations> ret = new LinkedList<Orientations>();
		
		outer:
		for (int i = 0 ; i < 6; i++){
			Orientations o = Orientations.values()[i];
			boolean found = false;
			for(ExitRoute route : _adjacent.values()) {
				if (route.exitOrientation == o){
					found = true;
					continue outer; //Its routed
				}
			}
			ret.add(o);	//Its not (might not be a pipe, but its not routed)
		}
		return ret;
	}
	
	public boolean isRoutedExit(Orientations o){
		return !GetNonRoutedExits().contains(o);
	}
	

	public void displayRoutes(){
		_laser.displayRoute(this);
		
	}
	

}


