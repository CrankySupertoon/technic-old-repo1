/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

import net.minecraft.src.buildcraft.krapht.logic.PipeLogicLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsProviderLogistics;
import net.minecraft.src.krapht.ItemIdentifier;

public class LogisticsManager {
	private class LogisticsValue {
		int TotalThisCycle = 0;
		int CompletedThisCycle = 0;
		float cycleCompletedFraction;

		public LogisticsValue(int TotalToDeliver) {
			this.TotalThisCycle = TotalToDeliver;
			recalc();
		}
		
		public void deliverItem() {
			CompletedThisCycle++;
			recalc();
		}
		
		public void setCompleted() {
			CompletedThisCycle = TotalThisCycle;
			recalc();
		}
		
		private void recalc(){
			cycleCompletedFraction = TotalThisCycle == 0 ? 1F : (1F / (float) TotalThisCycle) * (float) CompletedThisCycle;
		}
	}
	
	private static HashMap<ItemIdentifier, HashMap<Router, LogisticsValue >>  _logisticsDatabase = new HashMap<ItemIdentifier, HashMap<Router,LogisticsValue>>();
	private static LogisticsManager _instance;
	
	static { //Workaround to create instances of internal class
		_instance = new LogisticsManager();
	}
	
	public static Router getDestinationFor(ItemIdentifier item, Set<Router> validDestinations) {
		if (!_logisticsDatabase.containsKey(item)){
			_logisticsDatabase.put(item, new HashMap<Router, LogisticsValue>());
		}
		
		HashMap<Router, LogisticsValue> itemEntry = _logisticsDatabase.get(item);
		
		Router nextDestination = null;
		LogisticsValue nextDestinationValue = null;
		
		
		boolean allCompleted = true;
		for (Router r : validDestinations) {
			if (!itemEntry.containsKey(r)){
				if (!(r.getPipe().logic instanceof PipeLogicLogistics)) continue;
				itemEntry.put(r, _instance.new LogisticsValue(((PipeLogicLogistics)r.getPipe().logic).RequestsItem(item)));
			}
			LogisticsValue value = itemEntry.get(r);
			if (value.cycleCompletedFraction < 1F) {
				allCompleted = false;
				continue;
			}
		}
		
		if (allCompleted) {
			for (Router r : validDestinations){
				if (!(r.getPipe().logic instanceof PipeLogicLogistics)) continue;
				itemEntry.put(r, _instance.new LogisticsValue(((PipeLogicLogistics)r.getPipe().logic).RequestsItem(item)));				
			}
		}
		
		for (Router r : validDestinations) {
			LogisticsValue value = itemEntry.get(r);
			if (!(r.getPipe().logic instanceof PipeLogicLogistics)) continue;
			//Ensure router still desires items
			int requested = ((PipeLogicLogistics)r.getPipe().logic).RequestsItem(item);
			if (requested == 0){
				value.setCompleted();
			}
			
			if (value.cycleCompletedFraction == 1F)	{
				continue;
			}
			
			if (nextDestinationValue == null || value.cycleCompletedFraction < nextDestinationValue.cycleCompletedFraction)	{
				nextDestinationValue = value;
				nextDestination = r;
			}
		}
		
		if (nextDestinationValue != null){
			nextDestinationValue.deliverItem();
		}
		return nextDestination;
	}

	public static boolean canOrder(ItemIdentifier item, int count, Set<Router> validDestinations){
		//TODO: Get from the shortest, not the first
		return getAvailableCount(item, validDestinations) >= count;
	}
	
	public static int getAvailableCount(ItemIdentifier item, Set<Router> validDestinations){
		int count = 0;
		for (Router r : validDestinations) {
			if (r.getPipe() instanceof IProvideItems){
				IProvideItems provider = (IProvideItems) r.getPipe();
				count += provider.getAvailableItemCount(item);
			}
		}
		return count;
	}
	
//	public static void order(ItemIdentifier item, int count, Router destination, Set<Router> validDestinations){
//		int countLeft = count;
//		for (Router r : validDestinations){
//			if (!(r.getPipe() instanceof IProvideItems)) continue;
//			IProvideItems provider = (IProvideItems) r.getPipe();
//			int providable = provider.canProvide(item);
//			int needed = Math.min(countLeft, providable);
//			
//			provider.provide(item, needed, destination);
//			countLeft = countLeft-needed;
//			if (countLeft < 1)
//				return;
//		}
//			
//	}
	
	public static boolean Request(LogisticsRequest originalRequest, Set<Router> validDestinations){
		LogisticsTransaction transaction = new LogisticsTransaction(originalRequest);
		
		//First check all crafters
		for (Router r : validDestinations) {
			if (r.getPipe() instanceof ICraftItems) {
				((IProvideItems)r.getPipe()).canProvide(transaction);
			}
		}
		boolean added = true;
		while(!transaction.isDeliverable() && added){
			//Then check if we can do this without crafting any items.
			for( Router r : validDestinations) {
				if (r.getPipe() instanceof IProvideItems && !(r.getPipe() instanceof ICraftItems)){
					((IProvideItems)r.getPipe()).canProvide(transaction);
					if (transaction.isDeliverable()) break;
				}
			}
			if (!transaction.isDeliverable()){
				added = false;
				//Check the crafters and resolve anything craftable
				
				for(LogisticsRequest remaining : transaction.getRemainingRequests()){
					LinkedList<CraftingTemplate> possibleCrafts = transaction.getCrafts(remaining.getItem());
					if (possibleCrafts.isEmpty()) continue;
					while(!remaining.isReady()){				
						for(CraftingTemplate template : possibleCrafts){
							remaining.addPromise(template.generatePromise());
							for(LogisticsRequest newRequest : template.generateRequests()){
								transaction.addRequest(newRequest);
								added = true;
							}
						}
					}
				}
			}
		}
		
		if (!transaction.isDeliverable()) return false;

		for (LogisticsRequest request : transaction.getRequests()){
			for(LogisticsPromise promise : request.getPromises()) {
				promise.sender.fullFill(promise, request.getDestination());
				System.out.println(promise.sender.getRouter().getId() +  "\tSENDING " +promise.numberOfItems + promise.item.getDebugName() + " to " + request.getDestination().getRouter().toString());
			}
		}
		
//		for (LogisticsPromise promise : transaction.Promises()){
//			promise.sender.fullFill(promise, request.getDestination());
//		}
		return true;
	}
	
}
