package net.minecraft.src.krapht;

import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;

public class InventoryUtil {
	
	private IInventory _inventory;
	
	public InventoryUtil(IInventory inventory) {
		_inventory = inventory;
	}
	public int ItemCount(ItemIdentifier item){
		int count = 0;
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				count += stack.stackSize;
			}
		}
		return count;
	}
	
	public ItemStack GetItem(ItemIdentifier item){
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				ItemStack removed = stack.splitStack(1);
				if (stack.stackSize == 0){
					_inventory.setInventorySlotContents(i,  null);
				}
				return removed;
			}
		}
		return null;
	}
	

}
