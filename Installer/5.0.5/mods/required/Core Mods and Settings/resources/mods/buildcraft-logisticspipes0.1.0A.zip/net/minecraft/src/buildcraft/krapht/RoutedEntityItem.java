/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.World;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;

public class RoutedEntityItem extends EntityPassiveItem{

//	public int destinationX;
//	public int destinationY;
//	public int desitnationZ;
	public Router destinationRouter;
	public boolean isDefaultRouted;

	
	public RoutedEntityItem(World world, EntityPassiveItem entityItem) {
		super(world, entityItem.entityId);
		//System.out.println("Created routed entity for " + entityItem.item.getItemName());
		container = entityItem.container;
		deterministicRandomization = entityItem.deterministicRandomization;
		posX = entityItem.posX;
		posY = entityItem.posY;
		posZ = entityItem.posZ;
		speed = entityItem.speed;
		synchroTracker = entityItem.synchroTracker;
		item = entityItem.item; 
	}
	
//	public void SetDestination(int x, int y, int z)	{
//		this.destinationX = x;
//		this.destinationY = y;
//		this.desitnationZ = z;
//	}

}
