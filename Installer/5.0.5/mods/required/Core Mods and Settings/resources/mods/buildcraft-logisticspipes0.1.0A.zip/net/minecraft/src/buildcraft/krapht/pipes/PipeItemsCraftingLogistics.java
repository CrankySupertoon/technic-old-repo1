/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.pipes;

import java.util.HashMap;
import java.util.LinkedList;

import net.minecraft.src.ItemStack;
import net.minecraft.src.ItemTool;
import net.minecraft.src.TileEntity;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.factory.TileAutoWorkbench;
import net.minecraft.src.buildcraft.krapht.CraftingTemplate;
import net.minecraft.src.buildcraft.krapht.ICraftItems;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.LogisticsOrderManager;
import net.minecraft.src.buildcraft.krapht.LogisticsPromise;
import net.minecraft.src.buildcraft.krapht.LogisticsRequest;
import net.minecraft.src.buildcraft.krapht.LogisticsTransaction;
import net.minecraft.src.buildcraft.krapht.RoutedEntityItem;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.krapht.logic.PipeLogicCraftingLogistics;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;
import net.minecraft.src.krapht.ItemIdentifier;
import net.minecraft.src.krapht.ItemIdentifierStack;

public class PipeItemsCraftingLogistics extends RoutedPipe implements ICraftItems{

	private LinkedList<LogisticsRequest> _orders = new LinkedList<LogisticsRequest>();
	private LogisticsOrderManager _orderManager = new LogisticsOrderManager();
	
	public PipeItemsCraftingLogistics(int itemID) {
		super(new PipeLogicCraftingLogistics(), itemID);
	}

//	@Override
//	public int canProvide(ItemIdentifier item) {
//		
//		PipeLogicCraftingLogistics craftingLogic = (PipeLogicCraftingLogistics) this.logic;
//		ItemStack stack = craftingLogic.getStackInSlot(9); 
//		if ( stack == null) return 0;
//		if (ItemIdentifier.get(stack) != item) return 0;
//		
//		int totalDeliverable = Integer.MAX_VALUE;
//		//Check all materials
//		for (int i = 0; i < 9; i++){
//			ItemStack resourceStack = craftingLogic.getStackInSlot(i);
//			if (resourceStack == null) continue;
//			if (resourceStack.stackSize == 0) continue;
//			totalDeliverable = Math.min(totalDeliverable, LogisticsManager.getAvailableCount(ItemIdentifier.get(resourceStack), router.RouteTable.keySet()) / resourceStack.stackSize * stack.stackSize);
//		}
//		
//		return (totalDeliverable == Integer.MAX_VALUE ? 0  : totalDeliverable);
			
		
//		// Check adjacent crafting tables
//		LinkedList<TileAutoWorkbench> found = new LinkedList<TileAutoWorkbench>();
//		
//		for (int i = 0 ;i < 6; i++){
//			Position p = new Position(xCoord, yCoord, zCoord, Orientations.values()[i]);
//			p.moveForwards(1);
//			TileEntity tile = this.worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z); 
//			if (tile instanceof TileAutoWorkbench){
//				found.add((TileAutoWorkbench) tile);
//			}
//		}
//		if (!found.isEmpty()){
//			ItemStack stack = found.get(0).extractItem(false, Orientations.Unknown);
//			if (stack != null && ItemIdentifier.get(stack) == item){
//				return 1;
//			}
//		}
//
//		
//		// Check if resources are present
//		
//		// If not, check what can be ordered
//		return 0;
//	}

//	@Override
//	public void provide(ItemIdentifier item, int needed, Router destination) {
//		Order newOrder = new LogisticsManager.Order();
//		newOrder.destination = destination;
//		newOrder.count = needed;
//		newOrder.item = item;
//		_orders.add(newOrder);
//		
//		//Request all needed materials
//		PipeLogicCraftingLogistics craftingLogic = (PipeLogicCraftingLogistics) this.logic;
//		for (int i = 0; i < 9; i++){
//			ItemStack stack = craftingLogic.getStackInSlot(i);
//			if (stack == null) continue;
//			if (stack.stackSize == 0) continue;
//			LogisticsManager.order(ItemIdentifier.get(stack), stack.stackSize, this.router, this.router.RouteTable.keySet());
//		}		
//	}
	
	@Override
	public void updateEntity() {
		super.updateEntity();
		if (!_orderManager.hasOrders() || worldObj.getWorldTime() % 10 != 0) return;

		Position p = null;
		TileAutoWorkbench workBench = null;
		for (int i = 0 ;i < 6; i++){
			p = new Position(xCoord, yCoord, zCoord, Orientations.values()[i]);
			p.moveForwards(1);
			TileEntity tile = this.worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z); 
			if (tile instanceof TileAutoWorkbench){
				workBench =  (TileAutoWorkbench) tile;
				break;
			}
		}
		if (workBench == null || p == null){
			//if we can't find a workbench, abort all orders
			_orderManager.SendFailed();
			return;
		}

		System.out.print("Extracting!");		

		ItemStack stack = workBench.extractItem(true, Orientations.Unknown);
		if (stack == null ) return;
		while (stack.stackSize > 0){
			ItemStack stackToSend = stack.splitStack(1);
			if (_orderManager.hasOrders()){
				LogisticsRequest order = _orderManager.getNextRequest();
				super.sendRoutedItem(stackToSend, order.getDestination().getRouter(), p);
				_orderManager.SendSuccessfull(1);
			}else{
				Position entityPos = new Position(p.x + 0.5, p.y + Utils.getPipeFloorOf(stackToSend), p.z + 0.5, p.orientation.reverse());
				entityPos.moveForwards(0.5);
				EntityPassiveItem entityItem = new EntityPassiveItem(worldObj, entityPos.x, entityPos.y, entityPos.z, stackToSend);
				((PipeTransportItems) transport).entityEntering(entityItem, entityPos.orientation);
			}
		}
		
//		Iterator<LogisticsRequest> ppp = _orders.iterator();
//		while (ppp.hasNext()){
//			Order order = ppp.next();
//			ItemStack stack = workBench.extractItem(true, Orientations.Unknown);
//			if (stack == null ) continue;
//			
//			Position entityPos = new Position(p.x + 0.5, p.y + Utils.getPipeFloorOf(stack), p.z + 0.5, p.orientation.reverse());
//			entityPos.moveForwards(0.5);
//			
//			RoutedEntityItem routedItem = new RoutedEntityItem(worldObj, new EntityPassiveItem(worldObj, entityPos.x, entityPos.y, entityPos.z, stack));
//			routedItem.destinationRouter = order.destination;
//			routedItem.speed = Utils.pipeNormalSpeed * mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER;
//			((PipeTransportItems) transport).entityEntering(routedItem, entityPos.orientation);
//			
//			order.count--;
//			if (order.count < 1){
//				ppp.remove();
//			}
//			
//		}
	}
	
	
	private ItemIdentifier providedItem(){
		PipeLogicCraftingLogistics craftingLogic = (PipeLogicCraftingLogistics) this.logic;
		ItemStack stack = craftingLogic.getStackInSlot(9); 
		if ( stack == null) return null;
		return ItemIdentifier.get(stack);
	}
	

	@Override
	public int getCenterTexture() {
		// TODO Auto-generated method stub
		return mod_LogisticsPipes.LOGISTICSPIPE_CRAFTER_TEXTURE;
	}

	@Override
	public void canProvide(LogisticsTransaction transaction) {
		
		PipeLogicCraftingLogistics craftingLogic = (PipeLogicCraftingLogistics) this.logic;
		ItemStack stack = craftingLogic.getStackInSlot(9); 
		if ( stack == null) return;
		
		CraftingTemplate template = new CraftingTemplate(ItemIdentifierStack.GetFromStack(stack), this);

		//Check all materials
		for (int i = 0; i < 9; i++){
			ItemStack resourceStack = craftingLogic.getStackInSlot(i);
			if (resourceStack == null || resourceStack.stackSize == 0) continue;
			template.addRequirement(ItemIdentifierStack.GetFromStack(resourceStack));
		}
		transaction.addCraftingTemplate(template);
	}

	@Override
	public void fullFill(LogisticsPromise promise, IRequestItems destination) {
		_orderManager.AddOrder(new LogisticsRequest(promise.item, promise.numberOfItems, destination));
	}

	@Override
	public int getAvailableItemCount(ItemIdentifier item) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Router getRouter() {
		return router;
	}

}
