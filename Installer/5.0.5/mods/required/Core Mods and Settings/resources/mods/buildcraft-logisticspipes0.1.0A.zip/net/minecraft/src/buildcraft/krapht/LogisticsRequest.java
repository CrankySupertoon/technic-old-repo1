/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.LinkedList;

import net.minecraft.src.CraftingManager;
import net.minecraft.src.krapht.ItemIdentifier;

public class LogisticsRequest {
	private ItemIdentifier _item;
	private int _count;
	private IRequestItems _destination;
	
	private LinkedList<LogisticsPromise> _promises = new LinkedList<LogisticsPromise>(); 
	
	public LogisticsRequest(ItemIdentifier item, int numberOfItems, IRequestItems destination){
		this._item = item;
		this._count = numberOfItems;
		this._destination = destination;
	}
	
	public ItemIdentifier getItem(){
		return _item;
	}
	
	public int numberLeft(){
		return _count;
	}
	
	public void reduceNumberLeft(){
		_count--;
	}
	public void reduceNumberLeft(int count){
		_count -= count;		
	}
	
	public int notYetAllocated(){
		int totalAllocated = 0;
		for (LogisticsPromise promise : _promises){
			totalAllocated += promise.numberOfItems;
		}
		return _count - totalAllocated;
	}
	public boolean isReady(){
		return notYetAllocated() < 1;
	}
	
	public boolean isComplete() {
		return _count < 1;
	}
	
	public IRequestItems getDestination(){
		return _destination;
	}
	
	public void addPromise(LogisticsPromise promise){
		//Ensure promise never exceeds what we need
		if (promise.numberOfItems < 1)
			return;
		promise.numberOfItems = Math.min(promise.numberOfItems, notYetAllocated());
		_promises.add(promise);
	}
	
	public LinkedList<LogisticsPromise> getPromises(){
		return _promises;
	}
}


