/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.LinkedList;

import net.minecraft.src.krapht.ItemIdentifier;
import net.minecraft.src.krapht.ItemIdentifierStack;

public class CraftingTemplate {
	
	private ItemIdentifierStack _result;
	private ICraftItems _crafter;
	private LinkedList<ItemIdentifierStack> _required = new LinkedList<ItemIdentifierStack>();
	
	
	
	public CraftingTemplate(ItemIdentifierStack result, ICraftItems crafter){
		_result = result;
		_crafter = crafter;
	}
	
	public void addRequirement(ItemIdentifierStack stack){
		for(ItemIdentifierStack requirement : _required){
			if (requirement.getItem() == stack.getItem()){
				requirement.stackSize += stack.stackSize;
				return;
			}
		}
		_required.add(stack);
	}
	
	public LogisticsPromise generatePromise(){
		LogisticsPromise promise = new LogisticsPromise();
		promise.item = _result.getItem();
		promise.numberOfItems = _result.stackSize;
		promise.sender = _crafter;
		return promise;
	}
	
	public LinkedList<LogisticsRequest> generateRequests(){
		LinkedList<LogisticsRequest> requests = new LinkedList<LogisticsRequest>();
		for (ItemIdentifierStack stack : _required){
			requests.add(new LogisticsRequest(stack.getItem(), stack.stackSize, _crafter));
		}
		return requests;
	}

	public ItemIdentifierStack getResultStack() {
		return _result;
	}

}
