/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.logic;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.LogisticsManager;
import net.minecraft.src.buildcraft.krapht.LogisticsRequest;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.transport.PipeLogic;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeLogicRequestLogistics extends PipeLogic{

	@Override
	public boolean blockActivated(EntityPlayer entityplayer) {
		// TODO Auto-generated method stub
		
		if (entityplayer.getCurrentEquippedItem() != null){
			//boolean result = LogisticsManager.canOrder(ItemIdentifier.get(entityplayer.getCurrentEquippedItem()), 1, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.RouteTable.keySet());
			//if (result)
			//LogisticsManager.order(ItemIdentifier.get(entityplayer.getCurrentEquippedItem()), 1, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.RouteTable.keySet());
			LogisticsRequest request = new LogisticsRequest(ItemIdentifier.get(entityplayer.getCurrentEquippedItem()), entityplayer.getCurrentEquippedItem().stackSize, (IRequestItems) ((RoutedPipe)((TileGenericPipe)this.container).pipe)); 
			boolean result = LogisticsManager.Request(request, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.RouteTable.keySet());
			entityplayer.addChatMessage(result?"Request successfull!":"Request failed!");
			
		}
		
		if (entityplayer.getCurrentEquippedItem() == null)	{
			Router r = ((RoutedPipe)this.container.pipe).router;
			r.displayRoutes();
			if (mod_LogisticsPipes.DEBUG) {
				entityplayer.worldObj.setWorldTime(4951);
				System.out.println("ID: " + r.getId() + " - last sequence: " + r.getLastSequenceNumber());
			}
		}
		
		return true;
	}
}
