/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.LinkedList;

import net.minecraft.src.ItemStack;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.transport.IPipeTransportItemsHook;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.buildcraft.transport.PipeLogic;
import net.minecraft.src.buildcraft.transport.PipeTransport;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;

public abstract class RoutedPipe extends Pipe {

	public final Router router;
	

	private static int pipecount = 0;
	private int _delayOffset = 0;
	private int _nextTexture = getCenterTexture();
	
	public RoutedPipe(PipeLogic logic, int itemID) {
		super(new PipeTransportLogistics(), logic, itemID);
		((PipeTransportItems) transport).allowBouncing = true;
		router = new Router(this);
		
		pipecount++;
		//Roughly spread pipe updates throughout the frequency, no need to maintain balance
		_delayOffset = pipecount % mod_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY; 

	}
	
	public void sendRoutedItem(ItemStack item, Router destination, Position origin){
		Position entityPos = new Position(origin.x + 0.5, origin.y + Utils.getPipeFloorOf(item), origin.z + 0.5, origin.orientation.reverse());
		entityPos.moveForwards(0.5);
		
		RoutedEntityItem routedItem = new RoutedEntityItem(worldObj, new EntityPassiveItem(worldObj, entityPos.x, entityPos.y, entityPos.z, item));
		routedItem.destinationRouter = destination;
		routedItem.speed = Utils.pipeNormalSpeed * mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER;
		((PipeTransportItems) transport).entityEntering(routedItem, entityPos.orientation);
	}
	
	@Override
	public void updateEntity() {
		super.updateEntity();
		router.update(worldObj.getWorldTime() % mod_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY == _delayOffset);
	}	
	
	@Override
	public void destroy() {
		super.destroy();
		router.destroy();
		//Just in case
		pipecount = Math.max(pipecount - 1, 0);
	}
	
	@Override
	public final int getBlockTexture(){
		return _nextTexture;
	}
	
	public abstract int getCenterTexture();
	
	@Override
	public final void prepareTextureFor(Orientations connection) {

		if (connection == Orientations.Unknown || this.router == null){
			_nextTexture =  getCenterTexture();
			return;
		}
		
		if (this.router.isRoutedExit(connection)) {
			_nextTexture = mod_LogisticsPipes.LOGISTICSPIPE_ROUTED_TEXTURE;
		}
		else {
			_nextTexture = mod_LogisticsPipes.LOGISTICSPIPE_NOTROUTED_TEXTURE;
		}
	}
}
