/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.logic;

import net.minecraft.src.Block;
import net.minecraft.src.BuildCraftCore;
import net.minecraft.src.BuildCraftFactory;
import net.minecraft.src.BuildCraftTransport;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.krapht.GuiLogisticsPipe;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.krapht.Router.LSA;
import net.minecraft.src.buildcraft.transport.PipeLogic;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeLogicLogistics extends PipeLogic{

	ItemStack [] items = new ItemStack [9];
	
	private boolean _routeUpdateScheduled = true;
	private boolean _recalculateBestRoutes = true;
	private boolean _needInit = true;
	
	public boolean isDefaultRoute = false;

	public int RequestsItem(ItemIdentifier item) {
		if (item == null){
			return isDefaultRoute?1:0;
		}
		int total = 0;
		for(ItemStack is : items) {
			if (is == null) continue;
			if (item == ItemIdentifier.get(is)) {
				total += is.stackSize;
			}
		}
		return total;
	}
	

	@Override
	public boolean blockActivated(EntityPlayer entityplayer) {
		if (entityplayer.getCurrentEquippedItem() != null && entityplayer.getCurrentEquippedItem().getItem() == net.minecraft.src.BuildCraftCore.wrenchItem) {
			ModLoader.getMinecraftInstance().displayGuiScreen(new GuiLogisticsPipe(entityplayer.inventory, this.container, this));
			return true;
		}
		else if (entityplayer.getCurrentEquippedItem() == null)	{
			Router r = ((RoutedPipe)this.container.pipe).router;
			r.displayRoutes();
			
			if (mod_LogisticsPipes.DEBUG) {
				entityplayer.worldObj.setWorldTime(4951);
				System.out.println("***");
				for (Orientations o : ((RoutedPipe)this.container.pipe).router.GetNonRoutedExits())
				{
					System.out.println(o.toString());
				}
				System.out.println("***");
				
				System.out.println("ID: " + r.getId() + " - last sequence: " + r.getLastSequenceNumber());
				System.out.println("---------CONNECTED TO---------------");
				for (RoutedPipe adj : r._adjacent.keySet())
				{
					System.out.println(adj.router.getId());
				}
				System.out.println("+++++++++LSA DATABASE+++++++++++++++");
				System.out.println("LSA: " + r.LSADatabase.size());
				for (LSA lsa : r.LSADatabase)
				{
					String neighbours = ""; 
					for (Router router  : lsa.neighboursWithMetric.keySet()){
						neighbours += String.format("%s(%s), ", router.getId(), lsa.neighboursWithMetric.get(router).toString());
					}
						
					System.out.println(String.format("%s  \t%d\t%s",lsa.source.getId(), lsa.sequenceNumber, neighbours));
				}
	
				System.out.println("*******ROUTE TABLE**************");
				for (Router p : r.RouteTable.keySet())
				{
					System.out.println(p.getId() + " -> " + r.RouteTable.get(p).toString());
				}
				
				System.out.println();
				System.out.println();
				//r.SendNewLSA();
	//			//Give stuff! for debug purpose, ensure commented before release
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsStone, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsDiamond, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsWood, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.chest, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftEnergy.engineBlock, 64, 0));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchRedstoneActive, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.redstone, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchWood, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsIron, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsObsidian, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftCore.wrenchItem, 1));
	
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.glass, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftCore.goldGearItem, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftTransport.pipeItemsDiamond, 64));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchRedstoneActive, 1));
	//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftFactory.autoWorkbenchBlock, 64));
			}
		} 
 
//		else if(entityplayer.getCurrentEquippedItem().getItem() == net.minecraft.src.BuildCraftTransport.pipeItemsWood)
//		{
//			Router r = ((PipeItemsLogistics)this.container.pipe).Router;
//			r.SendNewLSA();
//		}
//		else {
//			
//			//refreshRoutes();
//			Router r = ((PipeItemsLogistics)this.container.pipe).Router;
//
//			if (entityplayer.getCurrentEquippedItem().getItem() == Item.pickaxeWood)
//			{
//				r.CreateRouteTable();
//			}
//			System.out.println();
//			System.out.println("ID: " + r.getId() + " - last sequence: " + r.getLastSequenceNumber());
//			System.out.println("---------CONNECTED TO---------------");
//			for (PipeItemsLogistics adj : r._adjacent.keySet())
//			{
//				System.out.println(adj.Router.getId());
//			}
//			System.out.println("+++++++++LSA DATABASE+++++++++++++++");
//			System.out.println("LSA: " + r.LSADatabase.size());
//			for (LSA lsa : r.LSADatabase)
//			{
//				String neighbours = ""; 
//				for (Router router  : lsa.neighboursWithMetric.keySet()){
//					neighbours += String.format("%s(%s), ", router.getId(), lsa.neighboursWithMetric.get(router).toString());
//				}
//					
//				System.out.println(String.format("%s  \t%d\t%s",lsa.source.getId(), lsa.sequenceNumber, neighbours));
//			}
//
//			System.out.println("*******ROUTE TABLE**************");
//			for (Router p : r.RouteTable.keySet())
//			{
//				System.out.println(p.getId() + " -> " + r.RouteTable.get(p).toString());
//			}
//			
//			System.out.println();
//			System.out.println();
//			
//		}
		return(true);
	}
	
	@Override
	public int getSizeInventory() {
		return items.length;
	}
	
	@Override
	public ItemStack getStackInSlot(int i) {
		return items [i];
	}

	@Override
	public ItemStack decrStackSize(int i, int j) {		
		ItemStack stack = items [i].copy();
		stack.stackSize = j;
		
		items [i].stackSize -= j;
		
		if (items [i].stackSize == 0) {
			items [i] = null;
		}
		return stack;
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		items [i] = itemstack;
	}
	
	@Override
	public String getInvName() {		
		return "Requested items";
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		// TODO Auto-generated method stub
		return true;
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound) {
		super.readFromNBT(nbttagcompound);	
		
		NBTTagList nbttaglist = nbttagcompound.getTagList("items");
    	
    	for (int j = 0; j < nbttaglist.tagCount(); ++j) {    		
    		NBTTagCompound nbttagcompound2 = (NBTTagCompound) nbttaglist.tagAt(j);
    		int index = nbttagcompound2.getInteger("index");
    		items [index] = ItemStack.loadItemStackFromNBT(nbttagcompound2);
    	}
    	isDefaultRoute = nbttagcompound.getBoolean("defaultdestination");
    }

    public void writeToNBT(NBTTagCompound nbttagcompound) {
    	super.writeToNBT(nbttagcompound);
    	
		NBTTagList nbttaglist = new NBTTagList();
    	
    	for (int j = 0; j < items.length; ++j) {    		    		
    		if (items [j] != null && items [j].stackSize > 0) {
        		NBTTagCompound nbttagcompound2 = new NBTTagCompound ();
        		nbttaglist.setTag(nbttagcompound2);
    			nbttagcompound2.setInteger("index", j);
    			items [j].writeToNBT(nbttagcompound2);	
    		}     		
    	}
    	
    	nbttagcompound.setTag("items", nbttaglist);
    	nbttagcompound.setBoolean("defaultdestination", isDefaultRoute);
    }
	
	@Override
	public boolean addItem(ItemStack stack, boolean doAdd, Orientations from) {
		return false;
	}

	@Override
	public ItemStack extractItem(boolean doRemove, Orientations from) {
		return null;
	}
}
