/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.HashMap;
import java.util.LinkedList;

import net.minecraft.src.TileEntity;
import net.minecraft.src.World;
import net.minecraft.src.buildcraft.api.API;
import net.minecraft.src.buildcraft.api.APIProxy;
import net.minecraft.src.buildcraft.api.LaserKind;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.EntityBlock;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.buildcraft.transport.pipes.PipeItemsIron;

public class RouteLaser {

	private LinkedList<EntityBlock> _lasers = new LinkedList<EntityBlock>();
	private Router _lastRouter;
	
	public void clear(){
		for(EntityBlock b : _lasers)
		APIProxy.removeEntity(b);
		_lasers = new LinkedList<EntityBlock>();
	}
	
	private void addLeg(World worldObj, Position start, Orientations o){
		Position end = new Position(start.x, start.y, start.z, o);			
		end.moveForwards(1);
		switch(o){
			case XNeg: case YNeg: case ZNeg:
				_lasers.add(Utils.createLaser(worldObj, end, start, LaserKind.Stripes));
				break;
			default:
				_lasers.add(Utils.createLaser(worldObj, start, end, LaserKind.Stripes));
		}
	}
	
	public void displayRoute(Router r){
		clear();
		if (r == _lastRouter){
			_lastRouter = null;
			return;
		}
		_lastRouter = r;
		LinkedList<Router> knownRouters = new LinkedList<Router>();
		for (Router table : r.RouteTable.keySet()){
			if (table == r) continue;
			knownRouters.add(table);
		}
		
		while (!knownRouters.isEmpty()){
			//Pick a router
			Router targetRouter = knownRouters.pop();
			boolean found = false;

			
			//Get the first exit
			Orientations next = r.RouteTable.get(targetRouter);
			if (next == Orientations.Unknown){
				System.out.println("BAAAD MOJO");
			}
			
			Router nextRouter = r;
			LinkedList<Router> visited = new LinkedList<Router>();
			while(nextRouter != targetRouter){
				if (visited.contains(nextRouter)){
					System.out.println("ROUTE LOOP");
					break;
				}
				visited.add(nextRouter);
					
				
				
				//Paint that route
				LinkedList<Router> discovered = new LinkedList<Router>();
				Position firstPos = new Position(nextRouter.getPipe().container.xCoord, nextRouter.getPipe().container.yCoord, nextRouter.getPipe().zCoord, next);
				addLeg(r.getPipe().worldObj, firstPos, next);
				paintPath(r.getPipe().worldObj, firstPos, new LinkedList<Position>(), discovered);
				
				if (discovered.isEmpty()){
					System.out.println("BAD ROUTE");
				}
				boolean ok = false;
				for (Router dicoveredRouter : discovered){
					if (knownRouters.contains(dicoveredRouter)){
						//knownRouters.remove(dicoveredRouter);
					}
					if (dicoveredRouter.RouteTable.containsKey(targetRouter))
					{
						ok = true;
						nextRouter = dicoveredRouter;
						next = dicoveredRouter.RouteTable.get(targetRouter);
					}
				}
				if (!ok){
					System.out.println("DEAD ROUTE");
					break;
				}
			}
		}
				
//		Position p1 = new Position(r.getPipe().container.xCoord, r.getPipe().container.yCoord, r.getPipe().zCoord);
//		for (int i = 0; i < 6; i++){
//			Orientations o = Orientations.values()[i];
//			if (!r.isRoutedExit(o)) continue;
//			Position firstPos = new Position(p1.x, p1.y, p1.z, o);
//			addLeg(r.getPipe().worldObj, firstPos, o);
//			paintPath(r.getPipe().worldObj, firstPos, new LinkedList<Position>());
//		}
	}
	
	private boolean paintPath(World worldObj, Position start, LinkedList<Position> visited, LinkedList<Router> discovered){
		if (visited.contains(start)){
			return false;
		}
		visited.add(start);
		
		start.moveForwards(1);
				
		TileEntity tile = worldObj.getBlockTileEntity((int) start.x, (int) start.y, (int) start.z);
		boolean found = false;
		if (tile instanceof TileGenericPipe) {
			if (((TileGenericPipe)tile).pipe instanceof RoutedPipe && visited.size() != 0) {
				discovered.add(((RoutedPipe)((TileGenericPipe)tile).pipe).router);
				return true;
			}
			for (int i = 0; i < 6; i++)	{
				Orientations nextOrientation = Orientations.values()[i];
				if (nextOrientation.reverse() == start.orientation) continue;
				Position nextPos = new Position(start.x, start.y, start.z, nextOrientation);
				
				boolean result = paintPath(worldObj, nextPos, (LinkedList<Position>)visited.clone(), discovered);
				found = found || result;
				if (result){
					addLeg(worldObj, start, nextOrientation);
				}
			}
		}
		return found;
	}
	
//	private void getConnectedRoutingPipes(TileGenericPipe startPipe, LinkedList<TileGenericPipe> visited)	{
//		
//		//Break recursion if we end up on a routing pipe, unless its the first one. Will break if matches the first call 
//		if (startPipe.pipe instanceof RoutedPipe && visited.size() != 0) {
//			return;
//		}
//		
//		//Visited is checked after, so we can reach the same target twice to allow to keep the shortest path 
//		visited.add(startPipe);
//		
//		//Iron pipes will separate networks
//		if (startPipe instanceof TileGenericPipe && (((TileGenericPipe)startPipe).pipe instanceof PipeItemsIron)){
//			return;
//		}
//		
//		//Recurse in all directions
//		for (int i = 0; i < 6; i++)	{
//			Position p = new Position(startPipe.xCoord, startPipe.yCoord, startPipe.zCoord, Orientations.values()[i]);
//			p.moveForwards(1);
//			TileEntity tile = startPipe.worldObj.getBlockTileEntity((int) p.x, (int) p.y, (int) p.z);
//			if (tile instanceof TileGenericPipe) {
//				getConnectedRoutingPipes(((TileGenericPipe)tile), (LinkedList<TileGenericPipe>)visited.clone());
//				for(RoutedPipe pipe : result.keySet()) 	{
//					//Update Result with the direction we took
//					result.get(pipe).exitOrientation = Orientations.values()[i];
//					if (!foundPipes.containsKey(pipe)) {  
//						// New path
//						foundPipes.put(pipe, result.get(pipe));
//					}
//					else if (result.get(pipe).metric < foundPipes.get(pipe).metric)	{ 
//						//If new path is better, replace old path, otherwise do nothing
//						foundPipes.put(pipe, result.get(pipe));
//					}
//				}				
//			}
//		}
//		return foundPipes;
//	}
	

}
