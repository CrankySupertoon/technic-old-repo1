Installation:

1: Install Risugami's Modloader. If you don't know what that is, look it up on Google.
Follow the directions on his page to learn how to install mods. It will help you install this.
You're also going to need Flan's version of SDK's "ModLoaderMP" in order to use the Forge. Just follow the link from ForgeAPI.
(1b: install Risugami's Audiomod if you want sound effects)
2: Install Minecraft Forge API for CLIENT. Link to is in my OP.
3: Drop the contents of the minecraft folder inside your .minecraft folder (sorry if you're on a mac, I have no idea where this is). Merge them. If you do not have a mods folder,
this will make one. If you do not have a resources/mod folder, this will make one. The mod itself will be
in your /mods folder. The properties file for changing block IDs and default key configs is in the .minecraft
folder AFTER YOUR FIRST LOAD.

My forum name is x3n0ph0b3 if you have any questions.


