Instalacja Millénaire 

- zainstaluj ModLoader Beta 1.8.1
- usun katalog META-INF z pliku minecraft.jar
- wgraj zawartosc katalogu "Put in minecraft folder" do katalogu minecraft (.minecraft pod Windowsem) (obok katalogow bin, saves, itd.)
- wgraj plik zip z katalogu "Put in mods folder" w katalogu minecraft/mods (bez rozpakowywania). Jesli nie ma podkatalogu "mods" to go stworz.
- zadnych plikow z Millénaire nie wgrywamy juz do pliku minecraft.jar. Zostalo to zastapione wgrywaniem pliku zip do katalogu mods.

Jesli mod dziala poprawnie to po pierwszym wczytaniu swiata pojawi sie napis: "Millénaire jest zaladowane. Odkrywaj i nacisnij 'v' by odnalezc wioski."

Aktualizacja Millénaire

- jesli nie robiles zmian w plikach Millénaire to po ptostu skasuj stary katalog millenaire i plik zip millenaire, a potem wgraj ich nowsze wersje
- jesli dokonywales zmian ( pliku config, do planow budynkow, itp.), musisz recznie przeniesc te zmiany do nowego katalogu millenaire, a potem skasowac stary

Potrzebujesz pomocy?

Zacznij od przejrzenia strony Millénaire Wiki na millenaire.wikia.com, a zwlaszcza sekcji FAQ gdzie sa odpowiedzi na powszechne pytania o instalacje Millénaire i na temat grania z modem. Jesli nie mozesz znalezc tam odpowiedzi spytaj w watku Millénaire na forum http://www.minecraftforum.net/
