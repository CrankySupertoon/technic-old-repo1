Millénaire installation

- installer ModLoader Beta 1.8.1
- slet META-INF fra minecraft.jar filen
- Kom indholdet fra "Put in minecraft folder" i minecraft mappen(.minecraft i Windows) (ved siden af bin, saves etc.)
- Kom zip filen fra "Put in mods folder" i minecraft/mods (uden at unzippe). Har du ikke mods mappen så lav den.
- Der er ikke nogen Millénaire classes der skal i minecraft.jar filen mere. Dette er erstattet af zip filen i mods mappen.

Hvis modden køre ordentligt vil den vise denne linje, når du connecter til verdenen, som siger at den er aktiv: "Millénaire er loaded. undersøg og pres "v" for at finde landsbyer

Millénaire update

- Hvis du ikke har ændret i Millénaire filerne, så skal du bare slette den gamle Millénaire mappe og Millénaire zip arkivet og erstatte dem med de nye som beskrevet tidligere.
- Hvis du har lavet ændringer ( til config filerne, till bygge planerne etc. ), Så skal du manuelt flytte dem til den nye Millénaire mappe. og så slette den gamle.



