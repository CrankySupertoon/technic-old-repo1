La traduzione italiana di Millénaire è stata curata da DucaDelSud.

La traduzione attualmente in uso, è la 1.2.6 v2 per la versione 1.2.6 di Millénaire e 1.7.3 di Minecraft.

Si prega di scrivere a millenaire_italian@hotmail.it nei seguenti casi:

1) Qualora sia disponibile una nuova versione di Millénaire ma non ancora la traduzione aggiornata in italiano;
2) Qualora si abbia riscontrato errori di battitura in qualche stringa;
3) Qualora si abbia idee su una traduzione diversa di alcune stringhe;


Saluti.