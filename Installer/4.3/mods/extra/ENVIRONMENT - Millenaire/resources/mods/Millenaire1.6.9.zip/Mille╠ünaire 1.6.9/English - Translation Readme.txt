Translation instructions

I'm always looking for more translations of Millénaire. If you want to participate, here are the basic instructions:
- First, mention that you are doing it in the forum thread and/or via PM to me, as other people might be working on the same thing
- Then duplicate an existing translation folder in "languages" and rename it to your language
- Open the files using a text editor with proper encoding support, meaning especially not Notepad on Windows. Good free editors include TextWrangler on Mac and PSPad, NotePad++ and UltraEdit on Windows
- Check on some sample text whether any special characters in your language (like ñ, ö, æ or ø) are properly displayed within Minecraft. Not all are, and this is not something I can fix.
- Translate all the text in it in that language to yours, save for the first half of each sentence that should remain in French (for Norman villagers) and Hindi (for Indians)
- Make sure you save everything in UTF-8 encoding
- You can generate a report on how complete your translation is by setting "generate_translation_gap" to true and launching the game. This is useful to check for added strings in new updates.
- Send it to me, and thanks!