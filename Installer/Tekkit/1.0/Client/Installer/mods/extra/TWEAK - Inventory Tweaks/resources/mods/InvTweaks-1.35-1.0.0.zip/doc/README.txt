|==============================================================|
| INVENTORY TWEAKS Mod - By Jimeo Wan (jimeo.wan at gmail.com) |
| Readme                                                       |
|==============================================================|

====== [ SETUP ] ======

1. Make sure ModLoader is already installed (http://www.minecraftforum.net/topic/75440-risugamis-mods)
2. Remove any previous version of Inventory Tweaks
3. Put this .zip in the "mods" folder of Minecraft [OR] Put all of the .zip contents in "minecraft.jar"
4. Launch the game! Look for the "..." button in your inventory to access the settings & help menu.

====== [ LINKS ] ======

* Minecraft Forum thread: http://www.minecraftforum.net/topic/323444-inventory-tweaks
* Official website: http://wan.ka.free.fr/?invtweaks
* Source code: https://github.com/jimeowan/inventory-tweaks