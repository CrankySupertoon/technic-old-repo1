PlasticCraft v2.2.2b for Minecraft 1.0.0
Moar technologiez.

Version 2.2.2b Changelog:
+ Added bottom texture for C4, and unique texture for Synthetic Fibre.
+ Gelatin can now be crafted with beef/chicken, alongside pork/leather.
* Fixed Extractor crashing when broken.
* Fixed cow breeding.
* Fixed texture bugs.
- Removed Plastic Wrap as it was redundant, since there's food stacking by default.

Version 2.2 Changelog:
+ Updated for Minecraft 1.0.0.
+ Now utilizes MCForge.
+ C4 now requires more then one punch to break.
* Plexiglass and Glowing Plexiglass are now combined into one block, using metadata instead for lighting.
* Plastic goo block damages correctly now.
- Removed Glowsticks, Jello, and the Red Record.
- Removed Achievements.

Installation:
(This is written on the premise you know how to get to your minecraft.jar)

1. Backup your minecraft.jar.
2. Delete META-INF from your minecraft.jar and close.
3. Install ModLoader and MinecraftForge into your minecraft.jar
4. Copy PlasticCraft.zip into /.minecraft/mods/
5. Start up minecraft and play.

On encountering an error:
- Copypaste the error into a post on my thread, surrounded by [code][/code] tags. If there are not [code] tags, I will probably ignore it.

FAQ:
(Read before posting on thread)^

Q: I haz blackscreen. Fix.
A: Delete META-INF.

Q: I installed this on (not 1.0.0) but I got blackscreen..
A: This mod is for 1.0.0.

Q: Why duzzn't recipes working?
A: Did you install ModLoader?

Q: "java.lang.NoClassDefFoundError: ModLoader" or "java.lang.NoClassDefFoundError: BaseMod"
A: Get ModLoader.

Q: "java.lang.IllegalArgumentException: Slot X is already occupied by Y@d1e7c2 when adding Z@c68a98"
A: Change X in PlasticCraft.cfg to something that isn't used. *this error means ID conflict*

Q: "java.lang.Exception: No more empty item sprite indices left!"
A: You have too many mods.

Q: How open .cfg file?
A: Notepad may, but I recommend Notepad++.

^ = If your problem isn't solved here, post an error log, and add "lolcat" to the end of your post. That way, I know you actually read this thing.