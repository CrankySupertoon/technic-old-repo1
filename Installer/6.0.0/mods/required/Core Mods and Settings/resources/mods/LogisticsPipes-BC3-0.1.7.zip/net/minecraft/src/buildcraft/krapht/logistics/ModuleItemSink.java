package net.minecraft.src.buildcraft.krapht.logistics;

import java.util.LinkedList;

import net.minecraft.src.GuiScreen;
import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.logistics.LogisticsModule.IHasModuleGui;
import net.minecraft.src.krapht.ItemIdentifier;

public class ModuleItemSink extends PassiveLogisticsModule implements IHasModuleGui{

	public ModuleItemSink(RoutedPipe p) {
		super(p);
	}

	@Override
	public LinkedList<String> getUpgradeSlots() {
		return new LinkedList<String>();
	}

	@Override
	public void openGui(GuiScreen previousGui) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValidTileEntity(TileEntity entity) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean SinksItem(ItemIdentifier item) {
		// TODO Auto-generated method stub
		return false;
	}
}