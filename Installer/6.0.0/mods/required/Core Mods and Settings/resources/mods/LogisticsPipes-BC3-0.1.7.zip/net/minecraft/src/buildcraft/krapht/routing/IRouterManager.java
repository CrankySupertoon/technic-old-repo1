package net.minecraft.src.buildcraft.krapht.routing;

import java.util.UUID;


public interface IRouterManager {

	public IRouter getOrCreateRouter(UUID id, int dimensionId, int xCoord, int yCoord, int zCoord);
	public IRouter getRouter(UUID id);
	public boolean isRouter(UUID id);
}
