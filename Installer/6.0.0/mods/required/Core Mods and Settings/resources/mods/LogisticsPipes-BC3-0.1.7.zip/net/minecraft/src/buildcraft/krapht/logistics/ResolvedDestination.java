package net.minecraft.src.buildcraft.krapht.logistics;

import java.util.UUID;

public class ResolvedDestination{
	public UUID bestRouter;
	public boolean isDefault;
	
	public ResolvedDestination(){}
	
	public ResolvedDestination(UUID bestRouter, boolean isDefault) {
		this.bestRouter = bestRouter;
		this.isDefault = isDefault;
	}
}