package net.minecraft.src.buildcraft.krapht.logistics;

import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public abstract class PassiveLogisticsModule extends LogisticsModule{

	public PassiveLogisticsModule(RoutedPipe p) {
		super(p);
	}
	
	public abstract boolean SinksItem(ItemIdentifier item);

}
