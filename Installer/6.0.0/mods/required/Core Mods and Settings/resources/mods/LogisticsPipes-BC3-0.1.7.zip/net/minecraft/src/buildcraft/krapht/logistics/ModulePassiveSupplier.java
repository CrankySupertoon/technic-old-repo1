package net.minecraft.src.buildcraft.krapht.logistics;

import java.util.LinkedList;

import net.minecraft.src.Block;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.SimpleServiceLocator;
import net.minecraft.src.buildcraft.krapht.logic.IHasItemConfig;
import net.minecraft.src.buildcraft.krapht.logistics.LogisticsModule.IHasModuleGui;
import net.minecraft.src.krapht.InventoryUtil;
import net.minecraft.src.krapht.ItemIdentifier;

public class ModulePassiveSupplier extends PassiveLogisticsModule implements IHasItemConfig, IHasModuleGui{

	private final RoutedPipe _pipe;
	
	public ModulePassiveSupplier(RoutedPipe p) {
		super(p);
		_pipe = p;
	}

	@Override
	public void openGui(GuiScreen previousGui) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public LinkedList<String> getUpgradeSlots() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValidTileEntity(TileEntity entity) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean SinksItem(ItemIdentifier item) {
		IInventory inv = _pipe.getTargetInventory();
		if (inv == null) return false;
		InventoryUtil invUtil = SimpleServiceLocator.inventoryUtilFactory.getInventoryUtil(inv);
		int currentCount = invUtil.itemCount(ItemIdentifier.get(new ItemStack(Block.dirt, 1)));
		return currentCount < 5;
	}
	
}