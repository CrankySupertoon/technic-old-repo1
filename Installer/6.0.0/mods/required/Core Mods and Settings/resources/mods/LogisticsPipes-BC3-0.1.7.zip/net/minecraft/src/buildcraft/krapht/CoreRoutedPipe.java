/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.UUID;

import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.krapht.logic.BaseRoutingLogic;
import net.minecraft.src.buildcraft.krapht.routing.IRouter;
import net.minecraft.src.buildcraft.krapht.routing.RoutedEntityItem;
import net.minecraft.src.buildcraft.transport.IPipeTransportItemsHook;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;

public abstract class CoreRoutedPipe extends Pipe implements IRequestItems{

	private IRouter router;
	private String routerId;
	private static int pipecount = 0;
	private int _delayOffset = 0;
	protected int _nextTexture = getCenterTexture();
	
	private boolean _initialInit = true;
	
	public int stat_session_sent;
	public int stat_session_recieved;
	public int stat_session_relayed;
	
	public long stat_lifetime_sent;
	public long stat_lifetime_recieved;
	public long stat_lifetime_relayed;
	
	protected boolean disabled = false;
	
	public CoreRoutedPipe(BaseRoutingLogic logic, int itemID) {
		super(new PipeTransportLogistics(), logic, itemID);
		((PipeTransportItems) transport).allowBouncing = true;
		
		pipecount++;
		//Roughly spread pipe updates throughout the frequency, no need to maintain balance
		_delayOffset = pipecount % core_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY; 

	}
	
	public void sendRoutedItem(ItemStack item, UUID destination, Position origin){
		Position entityPos = new Position(origin.x + 0.5, origin.y + Utils.getPipeFloorOf(item), origin.z + 0.5, origin.orientation.reverse());
		entityPos.moveForwards(0.5);
		
		RoutedEntityItem routedItem = new RoutedEntityItem(worldObj, new EntityPassiveItem(worldObj, entityPos.x, entityPos.y, entityPos.z, item));
		routedItem.sourceRouter = this.getRouter().getId();
		router.startTrackingRoutedItem(routedItem);
		routedItem.destinationRouter = destination;
		if (destination != null){
			SimpleServiceLocator.routerManager.getRouter(destination).startTrackingInboundItem(routedItem);
		}
		
		routedItem.speed = Utils.pipeNormalSpeed * core_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER;
		((PipeTransportItems) transport).entityEntering(routedItem, entityPos.orientation);
		stat_lifetime_sent++;
		stat_session_sent++;
			
	}
	
	@Override
	public void updateEntity() {
		super.updateEntity();
		getRouter().update(worldObj.getWorldTime() % core_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY == _delayOffset || _initialInit);
		_initialInit = false;
	}	
	
	@Override
	public void destroy() {
		super.destroy();
		router.destroy();
		if (logic instanceof BaseRoutingLogic){
			((BaseRoutingLogic)logic).destroy();
		}
		//Just in case
		pipecount = Math.max(pipecount - 1, 0);
	}
	
	public abstract int getCenterTexture();
	
	@Override
	public final void prepareTextureFor(Orientations connection) {

		if (connection == Orientations.Unknown || this.router == null){
			_nextTexture =  getCenterTexture();
			return;
		}
		
		if (this.router.isRoutedExit(connection)) {
			_nextTexture = getRoutedTexture(connection);
			
		}
		else {
			_nextTexture = getNonRoutedTexture(connection);
		}
	}
	
	public int getRoutedTexture(Orientations connection){
		return core_LogisticsPipes.LOGISTICSPIPE_ROUTED_TEXTURE;
	}
	
	public int getNonRoutedTexture(Orientations connection){
		return core_LogisticsPipes.LOGISTICSPIPE_NOTROUTED_TEXTURE;
	}
	
	@Override
	public void writeToNBT(NBTTagCompound nbttagcompound) {
		// TODO Auto-generated method stub
		super.writeToNBT(nbttagcompound);
		nbttagcompound.setString("routerId", routerId);
		nbttagcompound.setLong("stat_lifetime_sent", stat_lifetime_sent);
		nbttagcompound.setLong("stat_lifetime_recieved", stat_lifetime_recieved);
		nbttagcompound.setLong("stat_lifetime_relayed", stat_lifetime_relayed);
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbttagcompound) {
		// TODO Auto-generated method stub
		super.readFromNBT(nbttagcompound);
		routerId = nbttagcompound.getString("routerId");
		
		stat_lifetime_sent = nbttagcompound.getLong("stat_lifetime_sent");
		stat_lifetime_recieved = nbttagcompound.getLong("stat_lifetime_recieved");
		stat_lifetime_relayed = nbttagcompound.getLong("stat_lifetime_relayed");
	}
	
	@Override
	public IRouter getRouter() {
		if (router == null){
			if (routerId == null || routerId == ""){
				routerId = UUID.randomUUID().toString();
			}
			router = SimpleServiceLocator.routerManager.getOrCreateRouter(UUID.fromString(routerId), worldObj.getWorldInfo().getDimension(), xCoord, yCoord, zCoord);
		}
		return router;
	}
	

	public void onNeighborBlockChange_Logistics(){}
	
	public IInventory getTargetInventory(){
		return null;
	}
}
