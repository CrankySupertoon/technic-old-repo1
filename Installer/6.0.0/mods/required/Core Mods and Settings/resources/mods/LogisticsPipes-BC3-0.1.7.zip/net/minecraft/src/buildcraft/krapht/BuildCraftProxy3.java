package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.krapht.IBuildCraftProxy;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;

public class BuildCraftProxy3 implements IBuildCraftProxy{

	@Override
	public boolean checkPipesConnections(TileEntity tile1, TileEntity tile2) {
		return Utils.checkPipesConnections(tile1, tile2);
	}
}
