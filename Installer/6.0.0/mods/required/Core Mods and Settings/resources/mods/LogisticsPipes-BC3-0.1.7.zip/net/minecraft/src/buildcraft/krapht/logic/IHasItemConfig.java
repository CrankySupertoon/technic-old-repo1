package net.minecraft.src.buildcraft.krapht.logic;

public interface IHasItemConfig {

}
