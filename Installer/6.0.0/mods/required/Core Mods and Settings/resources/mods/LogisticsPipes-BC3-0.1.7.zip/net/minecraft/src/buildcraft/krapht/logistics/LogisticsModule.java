package net.minecraft.src.buildcraft.krapht.logistics;

import java.util.LinkedList;

import net.minecraft.src.GuiScreen;
import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;

public abstract class LogisticsModule {
	
	public interface IThrottledModule{
		public int getThrottleTime();
	}
	
	public interface IHasModuleGui{
		public void openGui(GuiScreen previousGui);
	}

	public class ItemSource extends LogisticsModule implements IThrottledModule, IHasModuleGui{

		public ItemSource(RoutedPipe p) {
			super(p);
		}

		@Override
		public int getThrottleTime() {
			return 100;
		}

		@Override
		public LinkedList<String> getUpgradeSlots() {return new LinkedList<String>();}

		@Override
		public void openGui(GuiScreen previousGui) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public boolean isValidTileEntity(TileEntity entity) {
			// TODO Auto-generated method stub
			return false;
		}
		
	}
	
	
	
	public class Provder extends LogisticsModule implements IHasModuleGui{

		public Provder(RoutedPipe p) {
			super(p);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void openGui(GuiScreen previousGui) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public LinkedList<String> getUpgradeSlots() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean isValidTileEntity(TileEntity entity) {
			// TODO Auto-generated method stub
			return false;
		}
		
	}
	
	public LogisticsModule(RoutedPipe p){
		
	}
	
	public abstract LinkedList<String> getUpgradeSlots();
	public abstract boolean isValidTileEntity(TileEntity entity);
	
}
