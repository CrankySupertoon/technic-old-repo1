package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.NBTTagCompound;

public interface ISaveState {
	public void readFromNBT(NBTTagCompound nbttagcompound, String prefix);
	public void writeToNBT(NBTTagCompound nbttagcompound, String prefix);
}
