package net.minecraft.src;

import java.io.File;

import net.minecraft.src.buildcraft.api.BuildCraftAPI;
import net.minecraft.src.buildcraft.api.Trigger;
//import net.minecraft.src.buildcraft.core.Action;
import net.minecraft.src.buildcraft.core.CoreProxy;
import net.minecraft.src.buildcraft.krapht.BuildCraftProxy3;
import net.minecraft.src.buildcraft.krapht.IBuildCraftProxy;
import net.minecraft.src.buildcraft.krapht.LogisticsTriggerProvider;
import net.minecraft.src.buildcraft.krapht.SimpleServiceLocator;
import net.minecraft.src.buildcraft.krapht.TriggerSupplierFailed;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsBuilderSupplierLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsSupplierLogistics;
import net.minecraft.src.forge.Configuration;
import net.minecraft.src.forge.Property;

public class mod_LogisticsPipes extends core_LogisticsPipes{
	//Triggers
	
	public mod_LogisticsPipes() {
		SimpleServiceLocator.setBuildCraftProxy(new BuildCraftProxy3());
	}

	public static Trigger LogisticsFailedTrigger;
	
	//public static Action LogisticsDisableAction;
	
	//Items
	public static Item LogisticsBuilderSupplierPipe;
	
	//Id
	public static int LOGISTICSPIPE_BUILDERSUPPLIER_ID			= 6880;
	
	//Textures
	public static int LOGISTICSPIPE_BUILDERSUPPLIER_TEXTURE		= 0;
	
	//Texture files
	public static final String LOGISTICSPIPE_BUILDERSUPPLIER_TEXTURE_FILE			= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipebuildersupplier.png";
	
	

	@Override
	public void ModsLoaded() {
		super.ModsLoaded();
		
		BuildCraftBuilders.initialize();
		
		this.LogisticsFailedTrigger = new TriggerSupplierFailed(700);
		BuildCraftAPI.registerTriggerProvider(new LogisticsTriggerProvider());
		
		Property logisticPipeBuilderSupplierIdProperty = configuration.getOrCreateIntProperty("logisticsPipeBuilderSupplier.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_BUILDERSUPPLIER_ID);
		logisticPipeBuilderSupplierIdProperty.comment = "The item id for the builder supplier pipe";
		
		configuration.save();
		
		LOGISTICSPIPE_BUILDERSUPPLIER_ID		= Integer.parseInt(logisticPipeBuilderSupplierIdProperty.value);
		
		LOGISTICSPIPE_BUILDERSUPPLIER_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_BUILDERSUPPLIER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_BUILDERSUPPLIER_TEXTURE + " for supplier texture");
		
		LogisticsBuilderSupplierPipe = createPipe(LOGISTICSPIPE_BUILDERSUPPLIER_ID, PipeItemsBuilderSupplierLogistics.class, "Builder Supplier Logistics Pipe");
		
		CraftingManager craftingManager = CraftingManager.getInstance();
		craftingManager.addRecipe(new ItemStack(LogisticsBuilderSupplierPipe, 1), new Object[]{"iPy", Character.valueOf('i'), new ItemStack(Item.dyePowder, 1, 0), Character.valueOf('P'), core_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('y'), new ItemStack(Item.dyePowder, 1,11)});

	}
	
	@Override
	public String getVersion() {
		return super.getLogisticsVersion() + " (built with Minecraft 1.1.0, Buildcraft 3.1.2, Forge 1.3.1)";
	}
}
