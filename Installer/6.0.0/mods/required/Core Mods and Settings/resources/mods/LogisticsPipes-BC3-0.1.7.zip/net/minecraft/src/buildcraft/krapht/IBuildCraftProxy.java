package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.TileEntity;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;

public interface IBuildCraftProxy {
	public boolean checkPipesConnections(TileEntity tile1, TileEntity tile2);
}
