//package net.minecraft.src.buildcraft.krapht;
//
//import net.minecraft.src.core_LogisticsPipes;
//import net.minecraft.src.buildcraft.core.Action;
//
//public class ActionDisableLogistics extends Action{
//
//	public ActionDisableLogistics(int id) {
//		super(id);
//	}
//	
//	@Override
//	public String getDescription() {
//		// TODO Auto-generated method stub
//		return super.getDescription();
//	}
//	
//	@Override
//	public int getIndexInTexture() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	
//	@Override
//	public String getTexture() {
//		// TODO Auto-generated method stub
//		return core_LogisticsPipes.LOGISTICSITEMS_TEXTURE_FILE;
//	}
//
//}
