//package net.minecraft.src.buildcraft.krapht.logistics;
//
//import org.lwjgl.opengl.GL11;
//
//import net.minecraft.src.Container;
//import net.minecraft.src.EntityPlayer;
//import net.minecraft.src.GuiButton;
//import net.minecraft.src.GuiContainer;
//import net.minecraft.src.IInventory;
//import net.minecraft.src.ModLoader;
//import net.minecraft.src.buildcraft.krapht.logic.IHasItemConfig;
//import net.minecraft.src.buildcraft.krapht.pipes.PipeLogisticsChassi;
//import net.minecraft.src.krapht.SimpleInventory;
//import net.minecraft.src.krapht.gui.DummyContainer;
//import net.minecraft.src.krapht.gui.SmallGuiButton;
//
//public class GuiChassiPipe extends GuiContainer{
//	
//	private PipeLogisticsChassi chassiPipe;
//	private final EntityPlayer _player;
//	
//	public GuiChassiPipe(EntityPlayer player, PipeLogisticsChassi chassi, IInventory dummyInventory) {
//		super(null);
//		_player = player;
//		chassiPipe = chassi;
//		
//		
//		DummyContainer dummy = new DummyContainer(_player.inventory, dummyInventory);
//		dummy.addNormalSlotsForPlayerInventory(18, 97);
//		dummy.addNormalSlot(0, dummyInventory, 18, 50);
//		
//
//		this.inventorySlots = dummy;
//		
//		//new DummyContainer(player.inventory, dummyInventory)
//	}
//	
//	@Override
//	public void initGui() {
//		xSize = 194;
//		ySize = 186;
//		super.initGui();
//		
//		controlList.clear();
//		for (int i = 0; i < chassiPipe.logiModules.length; i++){
//			if (chassiPipe.logiModules[i] instanceof IHasItemConfig){
//				controlList.add(new SmallGuiButton(i, 155, 39 + 20 * i, 45, 10, "Filters"));
//			}
//		}
//	}
//	
//	@Override
//	protected void actionPerformed(GuiButton guibutton) {
//		
//		if (guibutton.id >= 0 && guibutton.id <= 4){
//			ModLoader.OpenGUI(_player, new GuiFilter(_player, this, chassiPipe.moduleInventory[guibutton.id]));
//		}
//	}
//
//	
//	@Override
//	protected void drawGuiContainerForegroundLayer() {
//		super.drawGuiContainerForegroundLayer();
//		
//	}
//	
//	@Override
//	protected void drawGuiContainerBackgroundLayer(float f, int x, int y) {
//		int i = mc.renderEngine.getTexture("/net/minecraft/src/buildcraft/krapht/gui/pipechassi.png");
//		
//		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
//		mc.renderEngine.bindTexture(i);
//		int j = (width - xSize) / 2;
//		int k = (height - ySize) / 2;
//		drawTexturedModalRect(j, k, 0, 0, xSize, ySize);
//	}
//}
