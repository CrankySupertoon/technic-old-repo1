package net.minecraft.src.buildcraft.krapht.logistics;

import java.util.UUID;

import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.krapht.PipeTransportLogistics;
import net.minecraft.src.krapht.ItemIdentifier;

public interface ILogisticsManagerV2 {
	public ResolvedDestination getPassiveDestinationFor(ItemIdentifier item, UUID sourceRouter);
	
	public void handleIncommingItem(PipeTransportLogistics transport, EntityPassiveItem item);
	
}
