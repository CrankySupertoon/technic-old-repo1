package net.minecraft.src.buildcraft.krapht;

import java.util.LinkedList;

import net.minecraft.src.mod_LogisticsPipes;
//import net.minecraft.src.buildcraft.core.Action;
import net.minecraft.src.buildcraft.krapht.logic.BaseRoutingLogic;
import net.minecraft.src.buildcraft.transport.Pipe;

public abstract class RoutedPipe extends CoreRoutedPipe{
	public RoutedPipe(BaseRoutingLogic logic, int itemID) {
		super(logic, itemID);
	}
	
//	@Override
//	public LinkedList<Action> getActions() {
//		LinkedList<Action> actions = super.getActions();
//		actions.add(mod_LogisticsPipes.LogisticsDisableAction);
//		return actions;
//	}
	
	@Override
	public int getMainBlockTexture() {
		return _nextTexture;
	}
	
	@Override
	public void onNeighborBlockChange(int blockId) {
		super.onNeighborBlockChange(blockId);
		onNeighborBlockChange_Logistics();
	}
}
