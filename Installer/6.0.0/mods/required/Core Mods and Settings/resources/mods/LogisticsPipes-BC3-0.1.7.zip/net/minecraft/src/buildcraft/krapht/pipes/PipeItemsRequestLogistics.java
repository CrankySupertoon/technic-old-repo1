/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.pipes;

import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.logic.LogicRequest;
import net.minecraft.src.buildcraft.krapht.routing.Router;

public class PipeItemsRequestLogistics extends RoutedPipe implements IRequestItems{

	public PipeItemsRequestLogistics(int itemID) {
		super(new LogicRequest(), itemID);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCenterTexture() {
		// TODO Auto-generated method stub
		return core_LogisticsPipes.LOGISTICSPIPE_REQUESTER_TEXTURE;
	}

//	@Override
//	public Router getRouter() {
//		return router;
//	}
}
