package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.TileEntity;
import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.api.Trigger;
import net.minecraft.src.buildcraft.api.TriggerParameter;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsSupplierLogistics;
import net.minecraft.src.buildcraft.transport.ITriggerPipe;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;

public class TriggerSupplierFailed extends Trigger implements ITriggerPipe{

	public TriggerSupplierFailed(int id) {
		super(id);
	}
	
	@Override
	public int getIndexInTexture() {
		return 0 * 16 + 0;
	}
	
	@Override
	public String getDescription() {
		return "Supplier failed";
	}

	@Override
	public boolean isTriggerActive(Pipe pipe, TriggerParameter parameter) {
		if (!(pipe instanceof PipeItemsSupplierLogistics)) return false;
		PipeItemsSupplierLogistics supplier = (PipeItemsSupplierLogistics) pipe;
		return supplier.isRequestFailed();
	}

	@Override
	public String getTextureFile() {
		return core_LogisticsPipes.LOGISTICSACTIONTRIGGERS_TEXTURE_FILE;
	}
	
	
}
