package net.minecraft.src.buildcraft.krapht.routing;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.UUID;

import net.minecraft.src.ItemStack;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.krapht.CoreRoutedPipe;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;

public interface IRouter {
	public void destroy();
	public void update(boolean fullRefresh);
	public void sendRoutedItem(ItemStack item, Router destination, Position origin);
	public boolean isRoutedExit(Orientations connection);
	public Orientations getExitFor(UUID id);
	
	@Deprecated
	public HashMap<Router, Orientations> getRouteTable();
	@Deprecated
	public LinkedList<Router> getRoutersByCost(); 
	@Deprecated
	public LinkedList<Orientations> GetNonRoutedExits();
	@Deprecated
	public CoreRoutedPipe getPipe();
	@Deprecated
	public UUID getId();
	@Deprecated
	public int getInboundItemsCount();
	@Deprecated
	public int getOutboundItemsCount();
	@Deprecated
	public void itemDropped(RoutedEntityItem routedEntityItem);
	@Deprecated
	public void startTrackingRoutedItem(RoutedEntityItem routedEntityItem);
	@Deprecated
	public void startTrackingInboundItem(RoutedEntityItem routedEntityItem);
	@Deprecated
	public void displayRoutes();
	@Deprecated
	public void displayRouteTo(IRouter r);
	@Deprecated
	public void outboundItemArrived(RoutedEntityItem routedEntityItem);
	@Deprecated
	public void inboundItemArrived(RoutedEntityItem routedEntityItem);
}
