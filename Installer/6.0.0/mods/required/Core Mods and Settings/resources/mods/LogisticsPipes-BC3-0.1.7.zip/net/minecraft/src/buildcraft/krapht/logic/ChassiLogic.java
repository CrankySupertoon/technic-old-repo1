//package net.minecraft.src.buildcraft.krapht.logic;
//
//import org.lwjgl.input.Keyboard;
//
//import net.minecraft.src.EntityPlayer;
//import net.minecraft.src.GuiScreen;
//import net.minecraft.src.IInventory;
//import net.minecraft.src.ModLoader;
//import net.minecraft.src.TileEntity;
//import net.minecraft.src.buildcraft.api.ILiquidContainer;
//import net.minecraft.src.buildcraft.api.IPipeEntry;
//import net.minecraft.src.buildcraft.api.Orientations;
//import net.minecraft.src.buildcraft.krapht.logistics.GuiChassiPipe;
//import net.minecraft.src.buildcraft.krapht.pipes.PipeLogisticsChassi;
//import net.minecraft.src.buildcraft.transport.PipeLogicWood;
//import net.minecraft.src.buildcraft.transport.TileGenericPipe;
//import net.minecraft.src.krapht.SimpleInventory;
//
//public class ChassiLogic extends BaseRoutingLogic{
//	
//	@Override
//	public void onWrenchClicked(EntityPlayer entityplayer) {
//		
//		if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)){
//			((PipeLogisticsChassi)this.container.pipe).nextOrientation();
//		} else {
//			ModLoader.OpenGUI(entityplayer, new GuiChassiPipe(entityplayer, (PipeLogisticsChassi) this.container.pipe, new SimpleInventory(10, "null", 64)));
//		}
//	}
//
//	@Override
//	public void destroy() {
//
//		
//	}
//
//}
