/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.UUID;

import net.minecraft.src.TileEntity;
import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.krapht.logistics.ResolvedDestination;
import net.minecraft.src.buildcraft.krapht.routing.RoutedEntityItem;
import net.minecraft.src.buildcraft.transport.*;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeTransportLogistics extends PipeTransportItems {

	private class ResolvedRoute{
		UUID bestRouter;
		boolean isDefault;
	}
	
	private RoutedPipe _pipe = null;
	private HashMap<UUID, Orientations> routes = new HashMap<UUID, Orientations>(); 

	
	public PipeTransportLogistics() {
		allowBouncing = true;
	}

	private ResolvedRoute resolveRoute(EntityData data){
		ResolvedRoute route = new ResolvedRoute();
		
//		ResolvedDestination p = SimpleServiceLocator.logisticsManager.getPassiveDestinationFor(ItemIdentifier.get(data.item.item), _pipe.getRouter().getId());
//		
//		if (p != null){
//			route.bestRouter = p.bestRouter;
//			route.isDefault = p.isDefault;
//		} else {
			route.bestRouter = core_LogisticsPipes.logisticsManager.getDestinationFor(ItemIdentifier.get(data.item.item), _pipe.getRouter().getRouteTable().keySet());
			if (route.bestRouter == null){
				route.bestRouter = core_LogisticsPipes.logisticsManager.getDestinationFor(null, _pipe.getRouter().getRouteTable().keySet());
				route.isDefault = true;
			}
//		}
		return route;
	}
	
	//TODO: Refactor to reduce code duplication
	@Override
	public Orientations resolveDestination(EntityData data) {
		if (_pipe == null){
			_pipe = (RoutedPipe) container.pipe;
		}
		if (!(data.item instanceof RoutedEntityItem )){
			ResolvedRoute bestRoute = resolveRoute(data);
			
			if (bestRoute.bestRouter == null){
				//No idea where to send this. Drop it
				return Orientations.Unknown;
			}
			
			RoutedEntityItem newItem = new RoutedEntityItem(this.worldObj, data.item);
			newItem.setDefaultRouted(bestRoute.isDefault);
			newItem.sourceRouter = _pipe.getRouter().getId();
			newItem.destinationRouter = bestRoute.bestRouter;
			_pipe.getRouter().startTrackingRoutedItem(newItem);
			SimpleServiceLocator.routerManager.getRouter(bestRoute.bestRouter).startTrackingInboundItem(newItem);
			data.item = newItem;
			
			if (bestRoute.bestRouter != _pipe.getRouter().getId()){
				return _pipe.getRouter().getExitFor(bestRoute.bestRouter);
			}
			
			//If the best destination is the current router, continue
		}
		RoutedEntityItem item = (RoutedEntityItem)data.item;
		//a routed item with destination stripped. Check if we can get new route		
		if (item.destinationRouter == null)	{
			ResolvedRoute bestRoute = resolveRoute(data);
			
			if (bestRoute.bestRouter == null){
				//Unable to find a new destination, drop it
				return Orientations.Unknown;
			}
			item.setDefaultRouted(bestRoute.isDefault);
			item.destinationRouter = bestRoute.bestRouter;
			SimpleServiceLocator.routerManager.getRouter(bestRoute.bestRouter).startTrackingInboundItem(item);
		}
		
		if (item.destinationRouter == _pipe.getRouter().getId()){
			return destinationReached(item);
		}

		Orientations exit = _pipe.getRouter().getExitFor(item.destinationRouter); 
		if (exit != null) {
			item.refreshSpeed();
			if (item.sourceRouter != _pipe.getRouter().getId()){
				_pipe.stat_lifetime_relayed++;
				_pipe.stat_session_relayed++;
			}
			return(exit);
		}
		
		//No route, attempt to reroute!
		ResolvedRoute bestRoute = resolveRoute(data);
		if (bestRoute.bestRouter == null){
			//Failed, drop package
			return Orientations.Unknown;
		}
		item.changeDestination(bestRoute.bestRouter);
		item.setDefaultRouted(bestRoute.isDefault);
		if (item.destinationRouter == _pipe.getRouter().getId()){
			return destinationReached(item);
		}
		return _pipe.getRouter().getExitFor(item.destinationRouter);
	}
	
	private Orientations destinationReached(RoutedEntityItem item) {
		item.arrived = true;
		if (item.sourceRouter != null && SimpleServiceLocator.routerManager.getRouter(item.sourceRouter) != null){
			SimpleServiceLocator.routerManager.getRouter(item.sourceRouter).outboundItemArrived(item);
		}
		if  (item.destinationRouter != null && SimpleServiceLocator.routerManager.getRouter(item.destinationRouter) != null){
			SimpleServiceLocator.routerManager.getRouter(item.destinationRouter).inboundItemArrived(item);
		}
		
		_pipe.stat_lifetime_recieved++;
		_pipe.stat_session_recieved++;
		
		item.destinationRouter = null;
		
		//1) Deliver to attached chest/non-pipe
		LinkedList<Orientations> possible = getPossibleMovements(getPosition(), item);
		Iterator<Orientations> iterator = possible.iterator();
		while (iterator.hasNext())	{
			Position p = new Position(_pipe.xCoord, _pipe.yCoord, _pipe.zCoord, iterator.next());
			p.moveForwards(1);
			TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
			if (tile instanceof TileGenericPipe){
				iterator.remove();
			}
		}
		if (possible.size() > 0){
			return possible.get(worldObj.rand.nextInt(possible.size()));
		}
		
		//2) deliver to attached pipe that does not have a route
		LinkedList<Orientations> nonRoutes = _pipe.getRouter().GetNonRoutedExits();
		iterator = nonRoutes.iterator();
		while(iterator.hasNext()) {
			Position p = new Position(_pipe.xCoord, _pipe.yCoord, _pipe.zCoord, iterator.next());
			p.moveForwards(1);
			TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z); 
			if (tile == null || !( tile instanceof TileGenericPipe) || !((TileGenericPipe)tile).acceptItems()){
				iterator.remove();
			}
		}

		if (nonRoutes.size() != 0){
			return nonRoutes.get(worldObj.rand.nextInt(nonRoutes.size()));
		}
		
		//3) Eject				
		return Orientations.Unknown;
	}
	
	@Override
	public void entityEntering(EntityPassiveItem item, Orientations orientation) {
		// TODO Auto-generated method stub
		//SimpleServiceLocator.logisticsManager.handleIncommingItem(this, item);
		super.entityEntering(item, orientation);
	}
	
}

