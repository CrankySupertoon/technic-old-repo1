//package net.minecraft.src.buildcraft.krapht.logistics;
//
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.UUID;
//
//import net.minecraft.src.buildcraft.api.EntityPassiveItem;
//import net.minecraft.src.buildcraft.api.Orientations;
//import net.minecraft.src.buildcraft.krapht.CoreRoutedPipe;
//import net.minecraft.src.buildcraft.krapht.PipeTransportLogistics;
//import net.minecraft.src.buildcraft.krapht.SimpleServiceLocator;
//import net.minecraft.src.buildcraft.krapht.pipes.PipeLogisticsChassi;
//import net.minecraft.src.buildcraft.krapht.routing.RoutedEntityItem;
//import net.minecraft.src.buildcraft.krapht.routing.Router;
//import net.minecraft.src.krapht.ItemIdentifier;
//
//public class LogisticsManagerV2 implements ILogisticsManagerV2{
//
//	@Override
//	public ResolvedDestination getPassiveDestinationFor(ItemIdentifier item, UUID sourceRouter) {
//		// Get the routers that are accessible
//		LinkedList<Router> possibleRouters = SimpleServiceLocator.routerManager.getRouter(sourceRouter).getRoutersByCost();
//		for (Router  r : possibleRouters){
//			CoreRoutedPipe pipe = r.getPipe();
//			//Check for passive suppliers
//			if (!(pipe instanceof PipeLogisticsChassi)) continue;
//			PipeLogisticsChassi chassi = (PipeLogisticsChassi) pipe;
//			for(LogisticsModule mod : chassi.logiModules){
//				if (mod instanceof ModulePassiveSupplier){
//					if (((ModulePassiveSupplier)mod).SinksItem(item)){
//						return new ResolvedDestination(r.getId(), false);
//					}
//				}
//			}
//		}
//		
//		for (Router  r : possibleRouters){
//			CoreRoutedPipe pipe = r.getPipe();
//			//Check for sinks, closest first
//		}
//		
//		for (Router  r : possibleRouters){
//			CoreRoutedPipe pipe = r.getPipe();
//			//check for default route, closest first
//		}
//		
//		return null;
//	}
//
//	@Override
//	public void handleIncommingItem(PipeTransportLogistics transport, EntityPassiveItem item) {
//		if (item instanceof RoutedEntityItem) return;
//		
//	}
//
//}
