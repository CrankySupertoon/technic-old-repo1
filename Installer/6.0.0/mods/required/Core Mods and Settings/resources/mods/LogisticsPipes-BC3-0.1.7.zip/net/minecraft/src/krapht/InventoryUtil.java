/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.krapht;

import java.util.HashMap;

import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;

public class InventoryUtil {
	
	private final IInventory _inventory;
	
	public InventoryUtil(IInventory inventory) {
		_inventory = inventory;
	}
	
	public int itemCount(final ItemIdentifier item){
		int count = 0;
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				count += stack.stackSize;
			}
		}
		return count;
	}
	
	public HashMap<ItemIdentifier, Integer> getItemsAndCount(){
		HashMap<ItemIdentifier, Integer> items = new HashMap<ItemIdentifier, Integer>();
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			ItemIdentifier itemId = ItemIdentifier.get(stack);
			if (!items.containsKey(itemId)){
				items.put(itemId, stack.stackSize);
			} else {
				items.put(itemId, items.get(itemId) + stack.stackSize);
			}
		}	
		return items;
	}
	
	public int getItemCount(ItemIdentifier item){
		HashMap<ItemIdentifier, Integer> itemsAndCount = getItemsAndCount();
		if (!itemsAndCount.containsKey(item)){
			return 0;
		}
		return itemsAndCount.get(item);
	}
	
	public ItemStack getSingleItem(ItemIdentifier item){
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				ItemStack removed = stack.splitStack(1);
				if (stack.stackSize == 0){
					_inventory.setInventorySlotContents(i,  null);
				}
				return removed;
			}
		}
		return null;
	}
	
	public ItemStack getMultipleItems(ItemIdentifier item, int count){
		if (itemCount(item) < count) return null;
		ItemStack stack = null;
		for (int i = 0; i < count; i++){
			if(stack == null){
				stack = getSingleItem(item);
			}
			else{
				stack.stackSize += getSingleItem(item).stackSize;
			}
		}
		return stack;
	}
	
	public boolean containsItem(ItemIdentifier item){
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) return true;
		}
		return false;
	}
}
