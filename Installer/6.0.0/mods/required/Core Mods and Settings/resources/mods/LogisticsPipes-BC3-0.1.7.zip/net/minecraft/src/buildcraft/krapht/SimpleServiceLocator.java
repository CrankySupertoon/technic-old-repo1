package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.buildcraft.krapht.logistics.ILogisticsManagerV2;
import net.minecraft.src.buildcraft.krapht.routing.IRouterManager;
import net.minecraft.src.krapht.InventoryUtilFactory;

public final class SimpleServiceLocator {
	
	private SimpleServiceLocator(){};
	
	public static IBuildCraftProxy buildCraftProxy = null;
	public static void setBuildCraftProxy(final IBuildCraftProxy bcProxy){
		buildCraftProxy = bcProxy;
	}
	
	public static IRouterManager routerManager;
	public static void setRouterManager(final IRouterManager routerMngr){
		routerManager = routerMngr;
	}
	
	public static ILogisticsManagerV2 logisticsManager;
	public static  void setLogisticsManager(final ILogisticsManagerV2 logisticsMngr){
		logisticsManager = logisticsMngr;
	}
	
	public static InventoryUtilFactory inventoryUtilFactory;
	public static  void setInventoryUtilFactory(final InventoryUtilFactory invUtilFactory){
		inventoryUtilFactory = invUtilFactory;
	}
}
