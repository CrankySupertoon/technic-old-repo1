/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.routing;

import java.util.UUID;

import net.minecraft.src.EntityItem;
import net.minecraft.src.World;
import net.minecraft.src.core_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.krapht.IRequireReliableTransport;
import net.minecraft.src.buildcraft.krapht.SimpleServiceLocator;
import net.minecraft.src.krapht.ItemIdentifier;

public class RoutedEntityItem extends EntityPassiveItem{

	public UUID sourceRouter;
	public UUID destinationRouter;
	//public UUID lastHop;
	private boolean _isDefaultRouted;
	public boolean arrived;

	
	public RoutedEntityItem(World world, EntityPassiveItem entityItem) {
		super(world, entityItem.entityId);
		container = entityItem.container;
		deterministicRandomization = entityItem.deterministicRandomization;
		posX = entityItem.posX;
		posY = entityItem.posY;
		posZ = entityItem.posZ;
		speed = entityItem.speed;
		synchroTracker = entityItem.synchroTracker;
		item = entityItem.item; 
	}
	
	@Override
	public EntityItem toEntityItem(Orientations dir) {
		return super.toEntityItem(dir);
	}
	
	public boolean isDefaultRouted(){
		return _isDefaultRouted;
	}
	
	public void setDefaultRouted(boolean isDefault){
		_isDefaultRouted = isDefault;
		refreshSpeed();
	}
	
	public void refreshSpeed(){
		speed = Math.max(speed, Utils.pipeNormalSpeed * (_isDefaultRouted?core_LogisticsPipes.LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER : core_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER));
	}
	
	public void changeDestination(UUID newDestination){
		if (destinationRouter != null){
			if (destinationRouter != null && SimpleServiceLocator.routerManager.isRouter(destinationRouter)){
				SimpleServiceLocator.routerManager.getRouter(destinationRouter).itemDropped(this);
			}
			if (!arrived && SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe() != null && SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe().logic instanceof IRequireReliableTransport){
				((IRequireReliableTransport)SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe().logic).itemLost(ItemIdentifier.get(item));
			}
		}
		destinationRouter = newDestination;
		
	}
	
	@Override
	public void remove() {
		
		if (sourceRouter != null && SimpleServiceLocator.routerManager.isRouter(sourceRouter)) {
			SimpleServiceLocator.routerManager.getRouter(sourceRouter).itemDropped(this);
		}
		
		if (destinationRouter != null && SimpleServiceLocator.routerManager.isRouter(destinationRouter)){
			SimpleServiceLocator.routerManager.getRouter(destinationRouter).itemDropped(this);
		}

		
		if (!arrived && destinationRouter != null && SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe() != null && SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe().logic instanceof IRequireReliableTransport){
			((IRequireReliableTransport)SimpleServiceLocator.routerManager.getRouter(destinationRouter).getPipe().logic).itemLost(ItemIdentifier.get(item));
		}
		super.remove();
	}
}
