package net.minecraft.src.buildcraft.logisticspipes.registration;

import net.minecraft.src.buildcraft.transport.Pipe;

public interface IDefinePipe {

	public int defaultID();
	public int setActualId();
	public int getActualId();
	public Class <? extends Pipe> getPipeClass();
	public String getName();
	
	
}
