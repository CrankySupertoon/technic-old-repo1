//package net.minecraft.src.buildcraft.krapht.pipes;
//
//import java.util.LinkedList;
//
//import net.minecraft.src.IInventory;
//import net.minecraft.src.TileEntity;
//import net.minecraft.src.core_LogisticsPipes;
//import net.minecraft.src.buildcraft.api.ILiquidContainer;
//import net.minecraft.src.buildcraft.api.IPipeEntry;
//import net.minecraft.src.buildcraft.api.Orientations;
//import net.minecraft.src.buildcraft.api.Position;
//import net.minecraft.src.buildcraft.krapht.RoutedPipe;
//import net.minecraft.src.buildcraft.krapht.SimpleServiceLocator;
//import net.minecraft.src.buildcraft.krapht.logic.BaseRoutingLogic;
//import net.minecraft.src.buildcraft.krapht.logic.ChassiLogic;
//import net.minecraft.src.buildcraft.krapht.logic.LogicBasic;
//import net.minecraft.src.buildcraft.krapht.logistics.ModuleItemSink;
//import net.minecraft.src.buildcraft.krapht.logistics.LogisticsModule;
//import net.minecraft.src.buildcraft.krapht.logistics.ModulePassiveSupplier;
//import net.minecraft.src.buildcraft.transport.PipeLogicWood;
//import net.minecraft.src.buildcraft.transport.TileGenericPipe;
//import net.minecraft.src.krapht.SimpleInventory;
//
//public class PipeLogisticsChassi extends RoutedPipe{
//
//	public final LogisticsModule[] logiModules = new  LogisticsModule[4];
//	public final SimpleInventory[] moduleInventory = new SimpleInventory[]{
//		new SimpleInventory(9, "Filter Slot 1", 127),
//		new SimpleInventory(9, "Filter Slot 2", 127),
//		new SimpleInventory(9, "Filter Slot 3", 127),
//		new SimpleInventory(9, "Filter Slot 4", 127)
//		
//	};
//	
//	public PipeLogisticsChassi(int itemID) {
//		super(new ChassiLogic(), itemID);
//		
////		logiModules[0] = new ModulePassiveSupplier(this);
////		logiModules[1] = new ModulePassiveSupplier(this);
////		logiModules[2] = new ModulePassiveSupplier(this);
////		logiModules[3] = new ModulePassiveSupplier(this);
//
//	}
//	
//	
//	
//	public TileEntity getPointedTileEntity(){
//		int meta = worldObj.getBlockMetadata(xCoord, yCoord, zCoord);
//		if (meta >= Orientations.values().length) return null;
//		
//		Position pos = new Position(xCoord, yCoord, zCoord, Orientations.values()[meta]);
//		pos.moveForwards(1.0);
//		return worldObj.getBlockTileEntity((int)pos.x, (int)pos.y, (int)pos.z);
//	}
//	
//	public void nextOrientation() {
//		int metadata = worldObj.getBlockMetadata(xCoord, yCoord, zCoord);
//		
//		int nextMetadata = metadata;
//		
//		for (int l = 0; l < 6; ++l) {
//			nextMetadata ++;
//			
//			if (nextMetadata > 5) {
//				nextMetadata = 0;
//			}
//			if (!isValidOrientation(Orientations.values()[nextMetadata])) continue;
//			worldObj.setBlockMetadata(xCoord, yCoord, zCoord, nextMetadata);
//			worldObj.markBlockAsNeedsUpdate(xCoord, yCoord, zCoord);
//			System.out.println("orientation:" + nextMetadata);
//			return;
//		}
//	}
//	
//	private boolean isValidOrientation(Orientations connection){
//		if (getRouter().isRoutedExit(connection)) return false;
//		Position pos = new Position(xCoord, yCoord, zCoord, connection);
//		pos.moveForwards(1.0);
//		TileEntity tile = worldObj.getBlockTileEntity((int)pos.x, (int)pos.y, (int)pos.z);
//
//		if (tile == null) return false;
//		return SimpleServiceLocator.buildCraftProxy.checkPipesConnections(this.container, tile);
//	}
//	
//	@Override
//	public int getCenterTexture() {
//		return core_LogisticsPipes.LOGISTICSPIPE_TEXTURE;
//	}
//	
//	@Override
//	public int getRoutedTexture(Orientations connection) {
//		return core_LogisticsPipes.LOGISTICSPIPE_CHASSI_ROUTED_TEXTURE;
//	}
//	
//	@Override
//	public int getNonRoutedTexture(Orientations connection) {
//		if (connection == Orientations.values()[worldObj.getBlockMetadata(xCoord, yCoord, zCoord)]){
//			return core_LogisticsPipes.LOGISTICSPIPE_CHASSI_DIRECTION_TEXTURE;
//		}
//		return core_LogisticsPipes.LOGISTICSPIPE_CHASSI_NOTROUTED_TEXTURE;
//	}
//	
//	@Override
//	public void onNeighborBlockChange_Logistics() {
//		if (!isValidOrientation(Orientations.values()[worldObj.getBlockMetadata(xCoord, yCoord, zCoord)])){
//			nextOrientation();
//		}
//	};
//	
//	@Override
//	public void onBlockPlaced() {
//		super.onBlockPlaced();
//		nextOrientation();
//	}
//	
//	@Override
//	public IInventory getTargetInventory() {
//		TileEntity tile = getPointedTileEntity();
//		if (tile instanceof TileGenericPipe) return null;
//		if (!(tile instanceof IInventory)) return null;
//		return (IInventory) tile;
//	}
//}
